<?PHP

if (!defined('CONF_INCLUDE')) {
    echo 'Nothing to see here !';
} else {
    define('MSGENCRYPTED', true); // Store messages encrypted in the database to prevent other database users from reading them - true/false - visit the setup page after editing!
    define('ENCRYPTKEY_PASS', '54745745745754458555'); // Recommended length: 32. Encryption key for messages
    define('AES_IV_PASS', '012345678912'); // Recommended length: 12. AES Encryption IV
    define('DBHOST', 'localhost'); // Database host
    define('DBUSER', 'mybbuser'); // Database user
    define('DBPASS', 'SecurePassword123!'); // Database password
    define('DBNAME', 'mybb_forum'); // Database
    define('PERSISTENT', true); // Use persistent database conection true/false
    define('PREFIX', ''); // Prefix - Set this to a unique value for every chat, if you have more than 1 chats on the same database or domain - use only alpha-numeric values (A-Z, a-z, 0-9, or _) other symbols might break the queries
    define('MEMCACHED', false); // Enable/disable memcached caching true/false - needs memcached extension and a memcached server.
	define("SECRET_KEY","889823832983289832");//Do not change without Programmer advise
    if(MEMCACHED){
        define('MEMCACHEDHOST', 'localhost'); // Memcached host
        define('MEMCACHEDPORT', '11211'); // Memcached port
    }
    define('DBDRIVER', 0); // Selects the database driver to use - 0=MySQL, 1=PostgreSQL, 2=sqlite
    if(DBDRIVER===2){
        define('SQLITEDBFILE', 'public_chat.sqlite'); // Filepath of the sqlite database, if sqlite is used - make sure it is writable for the webserver user
    }
    define('COOKIENAME', PREFIX . 'chat_session'); // Cookie name storing the session information
    define('LANG', 'en'); // Default language
}

?>