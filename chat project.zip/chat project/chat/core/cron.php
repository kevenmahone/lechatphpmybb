<?php

// run every minute doing various database cleanup task
function cron (): void
{
	global $dbo;

	$time   = time();
	if (get_setting('nextcron') > $time) {
		return;
	}
	update_setting('nextcron', $time + 10);
	
	// delete old sessions
	$GuestTimeout	 = time() - 60 * get_setting('guestexpire');
	$MemberTimeout	 = time() - 60 * get_setting('memberexpire');
	$TimeOutQuery	 = 'SELECT id, nickname, status FROM ' . PREFIX . 'sessions WHERE ';
	$TimeOutQuery	.= '( status <= 2 AND lastpost < '. $GuestTimeout . ') OR (status > 2 AND lastpost < '.$MemberTimeout.' );';
	$timedout = $dbo->query($TimeOutQuery);
	$stmt     = $dbo->prepare('DELETE FROM ' . PREFIX . 'sessions WHERE id=? ;');
	while ($tmp = $timedout->fetch(PDO::FETCH_NUM)) {
		$Id = $To = [];
		$To[] = $tmp[1];
		$Id[] = $tmp[0];
		if ($tmp[2] >= 2) {
			$log = $dbo->prepare('UPDATE ' . PREFIX . 'members SET lastlogout=? WHERE nickname=?;');
			$log->execute([time(), $To[0]]);
		}
		$stmt->execute([$Id[0]]);
	//	stmt->execute([$time, $time]);
	}

	
	// delete old messages
	$limit   = get_setting('messagelimit');
	$stmt    = $dbo->query('SELECT id FROM ' . PREFIX . "messages WHERE poststatus=1 OR poststatus=4 ORDER BY id DESC LIMIT 1 OFFSET $limit;");
	if ($id = $stmt->fetch(PDO::FETCH_NUM)) {
		$stmt    = $dbo->prepare('DELETE FROM ' . PREFIX . 'messages WHERE id<=?;');
		$stmt->execute($id);
	}
	$stmt    = $dbo->prepare('DELETE FROM ' . PREFIX . 'messages WHERE id IN (SELECT * FROM (SELECT id FROM ' . PREFIX . 'messages WHERE postdate<(?-60*(SELECT value FROM ' . PREFIX . "settings WHERE setting='messageexpire'))) AS t);");
	$stmt->execute([$time]);

	// delete expired ignored people
	$result  = $dbo->query('SELECT id FROM ' . PREFIX . 'ignored WHERE ign NOT IN (SELECT nickname FROM ' . PREFIX . 'sessions UNION SELECT nickname FROM ' . PREFIX . 'members UNION SELECT poster FROM ' . PREFIX . 'messages) OR ignby NOT IN (SELECT nickname FROM ' . PREFIX . 'sessions UNION SELECT nickname FROM ' . PREFIX . 'members UNION SELECT poster FROM ' . PREFIX . 'messages);');
	$stmt    = $dbo->prepare('DELETE FROM ' . PREFIX . 'ignored WHERE id=?;');
	while ($tmp = $result->fetch(PDO::FETCH_NUM)) {
		$stmt->execute($tmp);
	}

	// delete files that do not belong to any message
	$result  = $dbo->query('SELECT id FROM ' . PREFIX . 'files WHERE postid NOT IN (SELECT id FROM ' . PREFIX . 'messages UNION SELECT postid FROM ' . PREFIX . 'inbox);');
	$stmt    = $dbo->prepare('DELETE FROM ' . PREFIX . 'files WHERE id=?;');
	while ($tmp = $result->fetch(PDO::FETCH_NUM)) {
		$stmt->execute($tmp);
	}

	// delete old notes
	$limit   = get_setting('numnotes');
	$to_keep = [];
	$stmt    = $dbo->query('SELECT id FROM ' . PREFIX . "notes WHERE type=0 ORDER BY id DESC LIMIT $limit;");
	while ($tmp = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$to_keep[] = $tmp['id'];
	}
	$stmt    = $dbo->query('SELECT id FROM ' . PREFIX . "notes WHERE type=1 ORDER BY id DESC LIMIT $limit;");
	while($tmp = $stmt->fetch(PDO::FETCH_ASSOC)){
		$to_keep[] = $tmp['id'];
	}
	$query   = 'DELETE FROM ' . PREFIX . 'notes WHERE type!=2 AND type!=3';
	if (!empty($to_keep)) {
		$query  .= ' AND id NOT IN (';
		for ($i = count($to_keep); $i > 1; --$i) {
			$query  .= '?, ';
		}
		$query  .= '?)';
	}
	$stmt    = $dbo->prepare($query);
	$stmt->execute($to_keep);
	$result  = $dbo->query('SELECT editedby, COUNT(*) AS cnt FROM ' . PREFIX . "notes WHERE type=2 GROUP BY editedby HAVING cnt>$limit;");
	$stmt    = $dbo->prepare('DELETE FROM ' . PREFIX . 'notes WHERE (type=2 OR type=3) AND editedby=? AND id NOT IN (SELECT * FROM (SELECT id FROM ' . PREFIX . "notes WHERE (type=2 OR type=3) AND editedby=? ORDER BY id DESC LIMIT $limit) AS t);");
	while ($tmp = $result->fetch(PDO::FETCH_NUM)) {
		$stmt->execute([$tmp[0], $tmp[0]]);
	}

	// delete old captchas
	$stmt    = $dbo->prepare('DELETE FROM ' . PREFIX . 'captcha WHERE time<(?-(SELECT value FROM ' . PREFIX . "settings WHERE setting='captchatime'));");
	$stmt->execute([$time]);

	// delete member associated data of deleted accounts
	$dbo->query('DELETE FROM ' . PREFIX . 'inbox WHERE recipient NOT IN (SELECT nickname FROM ' . PREFIX . 'members);');
	$dbo->query('DELETE FROM ' . PREFIX . 'notes WHERE (type=2 OR type=3) AND editedby NOT IN (SELECT nickname FROM ' . PREFIX . 'members);');

	// Modification rooms
	// Check if some is in a room .. 
	$result  = $dbo->query('SELECT DISTINCT roomid FROM ' . PREFIX . 'sessions WHERE roomid is not null;');
	while ($active = $result->fetch(PDO::FETCH_ASSOC)) {
		// If some one is in room ... reset timeout counter
		$stmt= $dbo->prepare('UPDATE ' . PREFIX . 'rooms SET time = ? WHERE id = ?');
		$stmt->execute([$time, $active['roomid']]);
	}
	// Calculate rooms timeout yet
	$RoomTimeout = time() - 60 * get_setting('roomexpire');
	// Check witch room is in time out
	$stmt		= $dbo->prepare('SELECT id FROM ' . PREFIX . 'rooms WHERE time <= ? AND permanent = 0');
	$stmt->execute([$RoomTimeout]);
	if (!$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
		$rooms = [];
	}
	// If room's are in time out ... we delete them yet !
	foreach ($rooms as $room) {
		remove_room(false, $room['id']);
	}
	// End modifications for rooms
	
}

?>