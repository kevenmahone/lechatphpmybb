<?php


function update_db () : void
{
	global $dbo, $memcached;
	$dboversion		= (int) get_setting('dbversion');
	$msgencrypted	= (bool) get_setting('msgencrypted');
	if ($dboversion >= DBVERSION && $msgencrypted === MSGENCRYPTED) {
		return;
	}
	ignore_user_abort(true);
	set_time_limit(0);
	if (DBDRIVER === 0) {		//MySQL
		$memengine=' ENGINE=MEMORY';
		$diskengine=' ENGINE=InnoDB';
		$charset=' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin';
		$primary='integer PRIMARY KEY AUTO_INCREMENT';
		$longtext='longtext';
	} elseif (DBDRIVER === 1) {	//PostgreSQL
		$memengine='';
		$diskengine='';
		$charset='';
		$primary='serial PRIMARY KEY';
		$longtext='text';
	} else {					//SQLite
		$memengine='';
		$diskengine='';
		$charset='';
		$primary='integer PRIMARY KEY';
		$longtext='text';
	}
	$msg='';
	if ($dboversion < 2) {
		$dbo->exec('CREATE TABLE IF NOT EXISTS ' . PREFIX . "ignored (id integer unsigned NOT NULL PRIMARY KEY AUTO_INCREMENT, ignored varchar(50) NOT NULL, `by` varchar(50) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
	}
	if ($dboversion < 3) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('rulestxt', '');");
	}
	if ($dboversion < 4) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD incognito smallint NOT NULL;');
	}
	if ($dboversion < 5) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('globalpass', '');");
	}
	if ($dboversion < 6) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('dateformat', 'm-d H:i:s');");
	}
	if ($dboversion < 7) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'captcha ADD code char(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;');
	}
	if ($dboversion < 8) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('captcha', '0'), ('englobalpass', '0');");
		$ga=(int) get_setting('guestaccess');
		if ($ga===-1) {
			update_setting('guestaccess', 0);
			update_setting('englobalpass', 1);
		}elseif ($ga===4) {
			update_setting('guestaccess', 1);
			update_setting('englobalpass', 2);
		}
	}
	if ($dboversion < 9) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgencrypted', '0');");
		$dbo->exec('ALTER TABLE ' . PREFIX . 'settings MODIFY value varchar(20000) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'messages DROP postid;');
	}
	if ($dboversion < 10) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('css', ''), ('memberexpire', '60'), ('guestexpire', '15'), ('kickpenalty', '10'), ('entrywait', '120'), ('messageexpire', '14400'), ('messagelimit', '150'), ('maxmessage', 2000), ('captchatime', '600');");
	}
	if ($dboversion < 11) {
		$dbo->exec('ALTER TABLE ' , PREFIX . 'captcha CHARACTER SET utf8 COLLATE utf8_bin;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'filter CHARACTER SET utf8 COLLATE utf8_bin;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'ignored CHARACTER SET utf8 COLLATE utf8_bin;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'messages CHARACTER SET utf8 COLLATE utf8_bin;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'notes CHARACTER SET utf8 COLLATE utf8_bin;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'settings CHARACTER SET utf8 COLLATE utf8_bin;');
		$dbo->exec('CREATE TABLE ' . PREFIX . "linkfilter (id integer unsigned NOT NULL PRIMARY KEY AUTO_INCREMENT, `match` varchar(255) NOT NULL, `replace` varchar(255) NOT NULL, regex smallint NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_bin;");
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD style varchar(255) NOT NULL;');
		$result=$dbo->query('SELECT * FROM ' . PREFIX . 'members;');
		$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'members SET style=? WHERE id=?;');
		$F=load_fonts();
		while($temp=$result->fetch(PDO::FETCH_ASSOC)) {
			$style="color:#$temp[colour];";
			if (isset($F[$temp['fontface']])) {
				$style.=$F[$temp['fontface']];
			}
			if (strpos($temp['fonttags'], 'i')!==false) {
				$style.='font-style:italic;';
			}
			if (strpos($temp['fonttags'], 'b')!==false) {
				$style.='font-weight:bold;';
			}
			$stmt->execute([$style, $temp['id']]);
		}
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('colbg', '000000'), ('coltxt', 'FFFFFF'), ('maxname', '20'), ('minpass', '5'), ('defaultrefresh', '20'), ('dismemcaptcha', '0'), ('suguests', '0'), ('imgembed', '1'), ('timestamps', '1'), ('trackip', '0'), ('captchachars', '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), ('memkick', '1'), ('forceredirect', '0'), ('redirect', ''), ('incognito', '1');");
	}
	if ($dboversion < 12) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'captcha MODIFY code char(5) NOT NULL, DROP INDEX id, ADD PRIMARY KEY (id) USING BTREE;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'captcha ENGINE=MEMORY;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'filter MODIFY id integer unsigned NOT NULL AUTO_INCREMENT, MODIFY `match` varchar(255) NOT NULL, MODIFY replace varchar(20000) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'ignored MODIFY ignored varchar(50) NOT NULL, MODIFY `by` varchar(50) NOT NULL, ADD INDEX(ignored), ADD INDEX(`by`);');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'linkfilter MODIFY match varchar(255) NOT NULL, MODIFY replace varchar(255) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'messages MODIFY poster varchar(50) NOT NULL, MODIFY recipient varchar(50) NOT NULL, MODIFY text varchar(20000) NOT NULL, ADD INDEX(poster), ADD INDEX(recipient), ADD INDEX(postdate), ADD INDEX(poststatus);');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'notes MODIFY type char(5) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL, MODIFY editedby varchar(50) NOT NULL, MODIFY text varchar(20000) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'settings MODIFY id integer unsigned NOT NULL, MODIFY setting varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL, MODIFY value varchar(20000) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'settings DROP PRIMARY KEY, DROP id, ADD PRIMARY KEY(setting);');
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('chatname', "._('My Chat').");");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('topic', '');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgsendall', "._('%s - ').");");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgsendmem', "._('[M] %s - ').");");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgsendmod', "._('[Staff] %s - ').");");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgsendadm', "._('[Admin] %s - ').");");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgsendprv', "._('[%1$s to %2$s] - ').");");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('numnotes', '3');");
	}
	if ($dboversion < 13) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'filter CHANGE `match` filtermatch varchar(255) NOT NULL, CHANGE `replace` filterreplace varchar(20000) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'ignored CHANGE ignored ign varchar(50) NOT NULL, CHANGE `by` ignby varchar(50) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'linkfilter CHANGE `match` filtermatch varchar(255) NOT NULL, CHANGE `replace` filterreplace varchar(255) NOT NULL;');
	}
	if ($dboversion < 14) {
		if (MEMCACHED) {
			$memcached->delete(DBNAME . '-' . PREFIX . 'members');
			$memcached->delete(DBNAME . '-' . PREFIX . 'ignored');
		}
		if (DBDRIVER===0) {//MySQL - previously had a wrong SQL syntax and the captcha table was not created.
			$dbo->exec('CREATE TABLE IF NOT EXISTS ' . PREFIX . 'captcha (id integer unsigned NOT NULL PRIMARY KEY AUTO_INCREMENT, time integer unsigned NOT NULL, code char(5) NOT NULL) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_bin;');
		}
	}
	if ($dboversion < 15) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('mailsender', 'www-data <www-data@localhost>'), ('mailreceiver', 'Webmaster <webmaster@localhost>'), ('sendmail', '0'), ('modfallback', '1'), ('guestreg', '0');");
	}
	if ($dboversion < 17) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN nocache smallint NOT NULL DEFAULT 0;');
	}
	if ($dboversion < 18) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('disablepm', '0');");
	}
	if ($dboversion < 19) {
		$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('disabletext', ?);");
		$stmt->execute(['<h1>'._('Temporarily disabled').'</h1>']);
	}
	if ($dboversion < 20) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN tz smallint NOT NULL DEFAULT 0;');
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('defaulttz', 'UTC');");
	}
	if ($dboversion < 21) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN eninbox smallint NOT NULL DEFAULT 0;');
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('eninbox', '0');");
		if (DBDRIVER===0) {
			$dbo->exec('CREATE TABLE ' . PREFIX . "inbox (id integer unsigned NOT NULL PRIMARY KEY AUTO_INCREMENT, postid integer unsigned NOT NULL, postdate integer unsigned NOT NULL, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text varchar(20000) NOT NULL, INDEX(postid), INDEX(poster), INDEX(recipient)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;");
		} else {
			$dbo->exec('CREATE TABLE ' . PREFIX . "inbox (id $primary, postdate integer NOT NULL, postid integer NOT NULL, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text varchar(20000) NOT NULL);");
			$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_postid ON ' . PREFIX . 'inbox(postid);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_poster ON ' . PREFIX . 'inbox(poster);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_recipient ON ' . PREFIX . 'inbox(recipient);');
		}
	}
	if ($dboversion < 23) {
		$dbo->exec('DELETE FROM ' . PREFIX . "settings WHERE setting='enablejs';");
	}
	if ($dboversion < 25) {
		$dbo->exec('DELETE FROM ' . PREFIX . "settings WHERE setting='keeplimit';");
	}
	if ($dboversion < 26) {
		$dbo->exec('INSERT INTO ' . PREFIX . 'settings (setting, value) VALUES (\'passregex\', \'.*\'), (\'nickregex\', \'^[A-Za-z0-9]*$\');');
	}
	if ($dboversion < 27) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('externalcss', '');");
	}
	if ($dboversion < 28) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('enablegreeting', '0');");
	}
	if ($dboversion < 29) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('sortupdown', '0');");
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN sortupdown smallint NOT NULL DEFAULT 0;');
	}
	if ($dboversion < 30) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'filter ADD COLUMN cs smallint NOT NULL DEFAULT 0;');
		if (MEMCACHED) {
			$memcached->delete(DBNAME . '-' . PREFIX . "filter");
		}
	}
	if ($dboversion < 31) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('hidechatters', '0');");
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN hidechatters smallint NOT NULL DEFAULT 0;');
	}
	if ($dboversion < 32 && DBDRIVER === 0) {
		//recreate db in utf8mb4
		try{
			$olddb=new PDO('mysql:host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_WARNING, PDO::ATTR_PERSISTENT=>PERSISTENT]);
			$dbo->exec('DROP TABLE ' . PREFIX . 'captcha;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "captcha (id integer PRIMARY KEY AUTO_INCREMENT, time integer NOT NULL, code char(5) NOT NULL) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$result=$olddb->query('SELECT filtermatch, filterreplace, allowinpm, regex, kick, cs FROM ' . PREFIX . 'filter;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'filter;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "filter (id integer PRIMARY KEY AUTO_INCREMENT, filtermatch varchar(255) NOT NULL, filterreplace text NOT NULL, allowinpm smallint NOT NULL, regex smallint NOT NULL, kick smallint NOT NULL, cs smallint NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'filter (filtermatch, filterreplace, allowinpm, regex, kick, cs) VALUES(?, ?, ?, ?, ?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$result=$olddb->query('SELECT ign, ignby FROM ' . PREFIX . 'ignored;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'ignored;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "ignored (id integer PRIMARY KEY AUTO_INCREMENT, ign varchar(50) NOT NULL, ignby varchar(50) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'ignored (ign, ignby) VALUES(?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$dbo->exec('CREATE INDEX ' . PREFIX . 'ign ON ' . PREFIX . 'ignored(ign);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'ignby ON ' . PREFIX . 'ignored(ignby);');
			$result=$olddb->query('SELECT postdate, postid, poster, recipient, text FROM ' . PREFIX . 'inbox;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'inbox;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "inbox (id integer PRIMARY KEY AUTO_INCREMENT, postdate integer NOT NULL, postid integer NOT NULL UNIQUE, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text text NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'inbox (postdate, postid, poster, recipient, text) VALUES(?, ?, ?, ?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_poster ON ' . PREFIX . 'inbox(poster);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_recipient ON ' . PREFIX . 'inbox(recipient);');
			$result=$olddb->query('SELECT filtermatch, filterreplace, regex FROM ' . PREFIX . 'linkfilter;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'linkfilter;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "linkfilter (id integer PRIMARY KEY AUTO_INCREMENT, filtermatch varchar(255) NOT NULL, filterreplace varchar(255) NOT NULL, regex smallint NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'linkfilter (filtermatch, filterreplace, regex) VALUES(?, ?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$result=$olddb->query('SELECT nickname, passhash, status, refresh, bgcolour, regedby, lastlogin, timestamps, embed, incognito, style, nocache, tz, eninbox, sortupdown, hidechatters FROM ' . PREFIX . 'members;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'members;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "members (id integer PRIMARY KEY AUTO_INCREMENT, nickname varchar(50) NOT NULL UNIQUE, passhash char(32) NOT NULL, status smallint NOT NULL, refresh smallint NOT NULL, bgcolour char(6) NOT NULL, regedby varchar(50) DEFAULT '', lastlogin integer DEFAULT 0, timestamps smallint NOT NULL, embed smallint NOT NULL, incognito smallint NOT NULL, style varchar(255) NOT NULL, nocache smallint NOT NULL, tz smallint NOT NULL, eninbox smallint NOT NULL, sortupdown smallint NOT NULL, hidechatters smallint NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'members (nickname, passhash, status, refresh, bgcolour, regedby, lastlogin, timestamps, embed, incognito, style, nocache, tz, eninbox, sortupdown, hidechatters) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$result=$olddb->query('SELECT postdate, poststatus, poster, recipient, text, delstatus FROM ' . PREFIX . 'messages;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'messages;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "messages (id integer PRIMARY KEY AUTO_INCREMENT, postdate integer NOT NULL, poststatus smallint NOT NULL, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text text NOT NULL, delstatus smallint NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'messages (postdate, poststatus, poster, recipient, text, delstatus) VALUES(?, ?, ?, ?, ?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$dbo->exec('CREATE INDEX ' . PREFIX . 'poster ON ' . PREFIX . 'messages (poster);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'recipient ON ' . PREFIX . 'messages(recipient);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'postdate ON ' . PREFIX . 'messages(postdate);');
			$dbo->exec('CREATE INDEX ' . PREFIX . 'poststatus ON ' . PREFIX . 'messages(poststatus);');
			$result=$olddb->query('SELECT type, lastedited, editedby, text FROM ' . PREFIX . 'notes;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'notes;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "notes (id integer PRIMARY KEY AUTO_INCREMENT, type char(5) NOT NULL, lastedited integer NOT NULL, editedby varchar(50) NOT NULL, text text NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'notes (type, lastedited, editedby, text) VALUES(?, ?, ?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
			$result=$olddb->query('SELECT setting, value FROM ' . PREFIX . 'settings;');
			$data=$result->fetchAll(PDO::FETCH_NUM);
			$dbo->exec('DROP TABLE ' . PREFIX . 'settings;');
			$dbo->exec('CREATE TABLE ' . PREFIX . "settings (setting varchar(50) NOT NULL PRIMARY KEY, value text NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;");
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'settings (setting, value) VALUES(?, ?);');
			foreach($data as $tmp) {
				$stmt->execute($tmp);
			}
		}catch(PDOException $e) {
			send_fatal_error(_('No connection to database!'));
		}
	}
	if ($dboversion < 33) {
		$dbo->exec('CREATE TABLE ' . PREFIX . "files (id $primary, postid integer NOT NULL UNIQUE, filename varchar(255) NOT NULL, hash char(40) NOT NULL, type varchar(255) NOT NULL, data $longtext NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'files_hash ON ' . PREFIX . 'files(hash);');
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('enfileupload', '0'), ('msgattache', '%2\$s [%1\$s]'), ('maxuploadsize', '1024');");
	}
	if ($dboversion < 34) {
		$msg.='<br>'._('Note: Default CSS is now hardcoded and can be removed from the CSS setting');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN nocache_old smallint NOT NULL DEFAULT 0;');
	}
	if ($dboversion < 37) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members MODIFY tz varchar(255) NOT NULL;');
		$dbo->exec('UPDATE ' . PREFIX . "members SET tz='UTC';");
		$dbo->exec('UPDATE ' . PREFIX . "settings SET value='UTC' WHERE setting='defaulttz';");
	}
	if ($dboversion < 38) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('nextcron', '0');");
		$dbo->exec('DELETE FROM ' . PREFIX . 'inbox WHERE recipient NOT IN (SELECT nickname FROM ' . PREFIX . 'members);'); // delete inbox of members who deleted themselves
	}
	if ($dboversion < 39) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting, value) VALUES ('personalnotes', '1');");
		$result=$dbo->query('SELECT type, id FROM ' . PREFIX . 'notes;');
		$data = [];
		while($tmp=$result->fetch(PDO::FETCH_NUM)) {
			if ($tmp[0]==='admin') {
				$tmp[0]=0;
			}else{
				$tmp[0]=1;
			}
			$data[]=$tmp;
		}
		$dbo->exec('ALTER TABLE ' . PREFIX . 'notes MODIFY type smallint NOT NULL;');
		$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'notes SET type=? WHERE id=?;');
		foreach($data as $tmp) {
			$stmt->execute($tmp);
		}
		$dbo->exec('CREATE INDEX ' . PREFIX . 'notes_type ON ' . PREFIX . 'notes(type);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'notes_editedby ON ' . PREFIX . 'notes(editedby);');
	}
	if ($dboversion < 41) {
		$dbo->exec('DROP TABLE ' . PREFIX . 'sessions;');
		$dbo->exec('CREATE TABLE ' . PREFIX . "sessions (id $primary, session char(32) NOT NULL UNIQUE, nickname varchar(50) NOT NULL UNIQUE, status smallint NOT NULL, refresh smallint NOT NULL, style varchar(255) NOT NULL, lastpost integer NOT NULL, passhash varchar(255) NOT NULL, postid char(6) NOT NULL DEFAULT '000000', useragent varchar(255) NOT NULL, kickmessage varchar(255) DEFAULT '', bgcolour char(6) NOT NULL, entry integer NOT NULL, timestamps smallint NOT NULL, embed smallint NOT NULL, incognito smallint NOT NULL, ip varchar(45) NOT NULL, nocache smallint NOT NULL, tz varchar(255) NOT NULL, eninbox smallint NOT NULL, sortupdown smallint NOT NULL, hidechatters smallint NOT NULL, nocache_old smallint NOT NULL)$memengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'status ON ' . PREFIX . 'sessions(status);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'lastpost ON ' . PREFIX . 'sessions(lastpost);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'incognito ON ' . PREFIX . 'sessions(incognito);');
		$result=$dbo->query('SELECT nickname, passhash, status, refresh, bgcolour, regedby, lastlogin, timestamps, embed, incognito, style, nocache, nocache_old, tz, eninbox, sortupdown, hidechatters FROM ' . PREFIX . 'members;');
		$members=$result->fetchAll(PDO::FETCH_NUM);
		$result=$dbo->query('SELECT postdate, postid, poster, recipient, text FROM ' . PREFIX . 'inbox;');
		$inbox=$result->fetchAll(PDO::FETCH_NUM);
		$dbo->exec('DROP TABLE ' . PREFIX . 'inbox;');
		$dbo->exec('DROP TABLE ' . PREFIX . 'members;');
		$dbo->exec('CREATE TABLE ' . PREFIX . "members (id $primary, nickname varchar(50) NOT NULL UNIQUE, passhash varchar(255) NOT NULL, status smallint NOT NULL, refresh smallint NOT NULL, bgcolour char(6) NOT NULL, regedby varchar(50) DEFAULT '', lastlogin integer DEFAULT 0, timestamps smallint NOT NULL, embed smallint NOT NULL, incognito smallint NOT NULL, style varchar(255) NOT NULL, nocache smallint NOT NULL, nocache_old smallint NOT NULL, tz varchar(255) NOT NULL, eninbox smallint NOT NULL, sortupdown smallint NOT NULL, hidechatters smallint NOT NULL)$diskengine$charset");
		$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'members (nickname, passhash, status, refresh, bgcolour, regedby, lastlogin, timestamps, embed, incognito, style, nocache, nocache_old, tz, eninbox, sortupdown, hidechatters) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
		foreach($members as $tmp) {
			$stmt->execute($tmp);
		}
		$dbo->exec('CREATE TABLE ' . PREFIX . "inbox (id $primary, postdate integer NOT NULL, postid integer NOT NULL UNIQUE, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text text NOT NULL)$diskengine$charset;");
		$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'inbox (postdate, postid, poster, recipient, text) VALUES(?, ?, ?, ?, ?);');
		foreach($inbox as $tmp) {
			$stmt->execute($tmp);
		}
		$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_poster ON ' . PREFIX . 'inbox(poster);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_recipient ON ' . PREFIX . 'inbox(recipient);');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'inbox ADD FOREIGN KEY (recipient) REFERENCES ' . PREFIX . 'members(nickname) ON DELETE CASCADE ON UPDATE CASCADE;');
	}
	if ($dboversion < 42) {
		$dbo->exec('INSERT IGNORE INTO ' . PREFIX . "settings (setting, value) VALUES ('filtermodkick', '1');");
	}
	if ($dboversion < 43) {
		$stmt = $dbo->prepare('INSERT IGNORE INTO ' . PREFIX . "settings (setting, value) VALUES ('metadescription', ?);");
		$stmt->execute([_('A chat community')]);
	}
	if ($dboversion < 44) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('publicnotes', '0');");
	}
	if ($dboversion < 45) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('memkickalways', '0'), ('sysmessagetxt', 'ℹ️ &nbsp;'),('namedoers', '1');");
	}
	if ($dboversion < 46) {
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN loginfails integer unsigned NOT NULL DEFAULT 0;');
	}
	if ($dboversion < 47) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_reload_post_box', '0'), ('hide_reload_messages', '0'),('hide_profile', '0'),('hide_admin', '0'),('hide_notes', '0'),('hide_clone', '0'),('hide_rearrange', '0'),('hide_help', '0'),('max_refresh_rate', '150'),('min_refresh_rate', '5'),('postbox_delete_globally', '0'),('allow_js', '1');");
	}
	if ($dboversion < 48) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msgsendsge', '');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('nicktags', '0');");
		update_setting('msgsendsge', _('[RG] %s - '));
	}
    if ($dboversion < 49) {
        $dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_sys_mess', '0');");
        $dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('user_sys_mess', '0');");
        $dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN lastlogout integer DEFAULT 0;');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN hide_sysmess smallint NOT NULL DEFAULT 0;');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'sessions ADD COLUMN hide_sysmess smallint NOT NULL DEFAULT 0;');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN user_entry varchar(255) DEFAULT "";');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'sessions ADD COLUMN user_entry varchar(255) DEFAULT "";');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN user_exit varchar(255) DEFAULT "";');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'sessions ADD COLUMN user_exit varchar(255) DEFAULT "";');
	}
	if ($dboversion < 50) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('helptxt', '');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_rules', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_smiley', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_smiley_post', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('emoji_path',  '');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_emojis', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_tags', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('only_one_tag', '0');");
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN user_intro text;');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN user_avatar text;');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN user_caption varchar(128) DEFAULT "";');
        $dbo->exec('ALTER TABLE ' . PREFIX . 'sessions ADD COLUMN user_caption varchar(128) DEFAULT "";');
		$dbo->exec('CREATE TABLE ' . PREFIX . "tags (id $primary, tag_dropdown varchar(10) NOT NULL , tag_id smallint(4) NOT NULL , tag_text varchar(30) NOT NULL , tag_ehtext varchar(200) NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "emojis (id $primary, emoji varchar(20) NOT NULL , file varchar(255) NOT NULL , inpage boolean NOT NULL , user_level smallint(2) NOT NULL, height smallint(3) NOT NULL , width smallint(3) NOT NULL)$diskengine$charset;");
	}
	if ($dboversion < 51) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_avatars', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_inline_commands', '0');");
	}
	if ($dboversion < 52) {
		// Add a comment field to filter & linkfilter
		$dbo->exec('ALTER TABLE ' . PREFIX . 'filter ADD COLUMN filtercom varchar(64) DEFAULT "";');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'linkfilter ADD COLUMN filtercom varchar(64) DEFAULT "";');
		// Store the date when a guest is registered
		$dbo->exec('ALTER TABLE ' . PREFIX . 'members ADD COLUMN regedwhen integer DEFAULT 0;');
		// Start of Gallery implementation
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_gallery', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_gallery', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('galleryaccess', '3');");
	}
	if ($dboversion < 53) {
		// Add a page to display a help for posters
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_posthelp', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('postext', '');");
		// All we need for the multi room system
		$dbo->exec('CREATE TABLE ' . PREFIX . "rooms (id $primary, name varchar(50) NOT NULL UNIQUE, access smallint NOT NULL, time integer NOT NULL, permanent smallint NOT NULL DEFAULT(0))$diskengine$charset");
		$dbo->exec('ALTER TABLE  ' . PREFIX . 'sessions ADD COLUMN roomid integer;');
		$dbo->exec('ALTER TABLE  ' . PREFIX . 'messages ADD COLUMN roomid integer;');
		$dbo->exec('ALTER TABLE  ' . PREFIX . 'messages ADD COLUMN allrooms smallint NOT NULL DEFAULT(0);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'sroomid ON ' . PREFIX . 'sessions(roomid);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'mroomid ON ' . PREFIX . 'messages(roomid);');
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_room', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_rooms', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('roomcreateaccess', '7');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('roomaccess', '2');");
		
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('roomexpire', '10');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('channelvisinroom', '2');");
	}
	if ($dboversion < 54) {
		// Java messages for JavaScript detection
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msg_java_on',  '!! JAVASCRIPT IS ENABLED !!');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('msg_java_off', '- JAVASCRIPT IS DISABLED -');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('no_login_with_js', '1');");
		// Setting record to allow or deny mobile devices (default deny)
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_mobile', '0');");
		// Setting recors to allow or deny link posting in the main chat (for the room's it's handle individualy)
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_link_in_main', '1');");
		// Setting recors to allow or deny a news button
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_news_button', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('news_page', '');");
		// Setting recors to allow or deny a links button
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_links_button', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('links_page', '');");
		// Add a some fields to room table for room v2
		$dbo->exec('ALTER TABLE ' . PREFIX . 'rooms ADD COLUMN creator varchar(60) DEFAULT "";');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'rooms ADD COLUMN display smallint(2) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'rooms ADD COLUMN type smallint(2) NOT NULL;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'rooms ADD COLUMN password varchar(32) DEFAULT "";');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'rooms ADD COLUMN withlink smallint(2) NOT NULL;');
	}
	if ($dboversion < 55) {
		// What's needed for pm in conversation mode
		// Setting recors to allow or deny the conversation mode in pm for user @ status 3 (Members)
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_conv_mode', '0');");
		$dbo->exec('ALTER TABLE  ' . PREFIX . 'members ADD COLUMN conv_mode smallint NOT NULL DEFAULT 0;');
		$dbo->exec('ALTER TABLE  ' . PREFIX . 'sessions ADD COLUMN conv_mode smallint NOT NULL DEFAULT 0;');
		// Late add ... capacity to show hidden user classes in chatter list
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('hide_empty_classes', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_msg_mention', '0');");
	}
	if ($dboversion < 56) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('show_chatter_on_top', '1');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_user_follow', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('follow_usr_access', '3');");
	}
	if ($dboversion < 57) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('internal_topic', '');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('staff_topic', '');");
	}
	if ($dboversion < 58) {
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_user_rename', '0');");
	}

	update_setting('dbversion', DBVERSION);
	if ($msgencrypted !== MSGENCRYPTED) {
		if (!extension_loaded('sodium')) {
			send_fatal_error(sprintf(_('The %s extension of PHP is required for the encryption feature. Please install it first or set the encrypted setting back to false.'), 'sodium'));
		}
		$result=$dbo->query('SELECT id, text FROM ' . PREFIX . 'messages;');
		$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'messages SET text=? WHERE id=?;');
		while($message=$result->fetch(PDO::FETCH_ASSOC)) {
			try {
				if (MSGENCRYPTED) {
					$message['text']=base64_encode(sodium_crypto_aead_aes256gcm_encrypt($message['text'], '', AES_IV, ENCRYPTKEY));
				}else{
					$message['text']=sodium_crypto_aead_aes256gcm_decrypt(base64_decode($message['text']), (string)null, AES_IV, ENCRYPTKEY);
				}
			} catch (SodiumException $e) {
				send_error($e->getMessage());
			}
			$stmt->execute([$message['text'], $message['id']]);
		}
		$result=$dbo->query('SELECT id, text FROM ' . PREFIX . 'notes;');
		$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'notes SET text=? WHERE id=?;');
		while($message=$result->fetch(PDO::FETCH_ASSOC)) {
			try {
				if (MSGENCRYPTED) {
					$message['text']=base64_encode(sodium_crypto_aead_aes256gcm_encrypt($message['text'], '', AES_IV, ENCRYPTKEY));
				}else{
					$message['text']=sodium_crypto_aead_aes256gcm_decrypt(base64_decode($message['text']), (string)null, AES_IV, ENCRYPTKEY);
				}
			} catch (SodiumException $e) {
				send_error($e->getMessage());
			}
			$stmt->execute([$message['text'], $message['id']]);
		}
		update_setting('msgencrypted', (int) MSGENCRYPTED);
	}
	send_update($msg);
}

function check_db () : void
{
	global $dbo, $memcached;
	$options	= [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_PERSISTENT=>PERSISTENT];
	try {
		if (DBDRIVER === 0) {
			if (!extension_loaded('pdo_mysql')) {
				send_fatal_error(sprintf(_('The %s extension of PHP is required for the selected database driver. Please install it first.'), 'pdo_mysql'));
			}
			$dbo	= new PDO('mysql:host=' . DBHOST . ';dbname=' . DBNAME . ';charset=utf8mb4', DBUSER, DBPASS, $options);
		} elseif (DBDRIVER === 1) {
			if (!extension_loaded('pdo_pgsql')) {
				send_fatal_error(sprintf(_('The %s extension of PHP is required for the selected database driver. Please install it first.'), 'pdo_pgsql'));
			}
			$dbo	= new PDO('pgsql:host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS, $options);
		} else {
			if (!extension_loaded('pdo_sqlite')) {
				send_fatal_error(sprintf(_('The %s extension of PHP is required for the selected database driver. Please install it first.'), 'pdo_sqlite'));
			}
			$dbo	= new PDO('sqlite:' . SQLITEDBFILE, NULL, NULL, $options);
			$dbo->exec('PRAGMA foreign_keys = ON;');
		}
	} catch (PDOException $e) {
		try {
			//Attempt to create database
			if (DBDRIVER === 0) {
				$dbo	= new PDO('mysql:host=' . DBHOST, DBUSER, DBPASS, $options);
				if (false !== $dbo->exec('CREATE DATABASE ' . DBNAME)) {
					$dbo	= new PDO('mysql:host=' . DBHOST . ';dbname=' . DBNAME . ';charset=utf8mb4', DBUSER, DBPASS, $options);
				} else {
					send_fatal_error(_('No connection to database, please create a database and edit the script to use the correct database with given username and password!'));
				}
			} elseif (DBDRIVER === 1) {
				$dbo	= new PDO('pgsql:host=' . DBHOST, DBUSER, DBPASS, $options);
				if (false !== $dbo->exec('CREATE DATABASE ' . DBNAME)) {
					$dbo	= new PDO('pgsql:host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS, $options);
				} else {
					send_fatal_error(_('No connection to database, please create a database and edit the script to use the correct database with given username and password!'));
				}
			} else {
				if (isset($_REQUEST['action']) && $_REQUEST['action'] === 'setup') {
					send_fatal_error(_('No connection to database, please create a database and edit the script to use the correct database with given username and password!'));
				} else {
					send_fatal_error(_('No connection to database!'));
				}
			}
		} catch (PDOException $e) {
			if (isset($_REQUEST['action']) && $_REQUEST['action'] === 'setup') {
				send_fatal_error(_('No connection to database, please create a database and edit the script to use the correct database with given username and password!'));
			} else {
				send_fatal_error(_('No connection to database!'));
			}
		}
	}
	if (MEMCACHED) {
		if (!extension_loaded('memcached')) {
			send_fatal_error(_('The memcached extension of PHP is required for the caching feature. Please install it first or set the memcached setting back to false.'));
		}
		$memcached	= new Memcached();
		$memcached->addServer(MEMCACHEDHOST, MEMCACHEDPORT);
	}
	if (!isset($_REQUEST['action']) || $_REQUEST['action'] === 'setup') {
		if (!check_init()) {
			send_init();
		}
		update_db();
	} elseif ($_REQUEST['action'] === 'init') {
		init_chat();
	}
}

function send_update (string $msg) : void
{
	print_start ('update');
	echo '<h2>'._('Database successfully updated!',).'</h2>';
	echo '<br>'.form('setup');
	echo submit(_('Go to the Setup-Page'));
	echo '</form>'.$msg.'<br>';
	echo credit();
	print_end ();
}



?>