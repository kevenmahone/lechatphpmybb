<?php

function route_admin () : string 
{
	global $U, $dbo;


	if (!isset($_POST['do'])) {
		return '';
	} else {
		if ($_POST['do'] === 'createrooms' && $U['status'] >= get_setting('roomcreateaccess')) {
			rooms(manage_rooms());
		} else {
			if ($U['status'] < 5) {
				send_access_denied();
			}
		}
	}

	if ($_POST['do'] === 'clean') {
		if ($_POST['what'] === 'choose') {
			send_choose_messages();
		} elseif ($_POST['what'] === 'selected') {
			clean_selected((int) $U['status'], $U['nickname']);
		} elseif ($_POST['what'] === 'chat') {
			clean_chat();
		} elseif ($_POST['what'] === 'room') {
			clean_room();
		} elseif ($_POST['what'] === 'nick') {
			$stmt=$dbo->prepare('SELECT null FROM ' . PREFIX . 'members WHERE nickname = ? AND status >= ?;');
			$stmt->execute([$_POST['nickname'], $U['status']]);
			if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
				del_all_messages($_POST['nickname'], 0);
			}
		}
	} elseif ($_POST['do'] === 'kick') {
		if (isset($_POST['name'])) {
			if (isset($_POST['what']) && $_POST['what'] === 'purge') {
				kick_chatter($_POST['name'], $_POST['kickmessage'], true);
			} else {
				kick_chatter($_POST['name'], $_POST['kickmessage'], false);
			}
		}
	} elseif ($_POST['do'] === 'logout') {
		if (isset($_POST['name'])) {
			logout_chatter($_POST['name']);
		}
	} elseif ($_POST['do'] === 'sessions') {
		if (isset($_POST['kick']) && isset($_POST['nick'])) {
			kick_chatter([$_POST['nick']], '', false);
		} elseif (isset($_POST['logout']) && isset($_POST['nick'])) {
			logout_chatter([$_POST['nick']]);
		}
		send_sessions();
	} elseif ($_POST['do'] === 'register') {
		return register_guest(3, $_POST['name']);
	} elseif ($_POST['do'] === 'superguest') {
		return register_guest(2, $_POST['name']);
	} elseif ($_POST['do'] === 'status') {
		return change_status($_POST['name'], $_POST['set']);
	} elseif ($_POST['do'] === 'regnew') {
		return register_new($_POST['name'], $_POST['pass']);
	} elseif ($_POST['do'] === 'approve') {
		approve_session();
		send_approve_waiting();
	} elseif ($_POST['do'] === 'guestaccess') {
		if (isset($_POST['guestaccess']) && preg_match('/^[0123]$/', $_POST['guestaccess'])) {
			update_setting('guestaccess', $_POST['guestaccess']);
		}
	// Handle 'Last Seen' screen (**work in progress**)
	} elseif ($_POST['do'] === 'lastseen') {
		send_lastseen();
	// Handle Tags screen (creation / deletion of tags)
	} elseif ($_POST['do'] === 'tags') {
		send_tags(manage_tags());
	// Handle Filter screen (creation / deletion of filters)
	} elseif ($_POST['do'] === 'filter') {
		send_filter(manage_filter());
	// Handle Link Filter screen (creation / deletion of link filters)
	} elseif ($_POST['do'] === 'linkfilter') {
		send_linkfilter(manage_linkfilter());
	// Handle Topics
	} elseif ($_POST['do'] === 'topic') {
		if (isset($_POST['topic'])) {
			update_setting('topic', htmlspecialchars($_POST['topic']));
		}
	} elseif ($_POST['do'] === 'staff_topic') {
		if (isset($_POST['staff_topic'])) {
			update_setting('staff_topic', htmlspecialchars($_POST['staff_topic']));
		}
	} elseif ($_POST['do'] === 'internal_topic') {
		if (isset($_POST['internal_topic'])) {
			update_setting('internal_topic', htmlspecialchars($_POST['internal_topic']));
		}
	// Reset user's password
	} elseif ($_POST['do'] === 'passreset' && $U['status'] > 6) {
		return passreset($_POST['name'], $_POST['pass']);
	// Modification chat rooms
	} elseif ($_POST['do'] === 'rooms' && $U['status'] >= get_setting('roomcreateaccess')) {
		send_rooms(manage_rooms());
	}

	return '';
}

function send_admin (string $arg): void
{
	global $U, $dbo;

	print_start('admin');

	// Get actual guestaccess level
	$GuestAccess	= (int) get_setting('guestaccess');

	$Chatters  		= [];

	// Fill Chatters List with actual chatting chatter on line
	$stmt			= $dbo->query('SELECT nickname, style, status FROM ' . PREFIX . 'sessions WHERE entry!=0 AND status>0 ORDER BY LOWER(nickname);');
	while ($Chatter	= $stmt->fetch(PDO::FETCH_NUM)) {
		$Chatters[]	= [htmlspecialchars($Chatter[0]), $Chatter[1], $Chatter[2]];
	}

	// Preparing Chatter's list
	$ChatterList	= '<select name="name[]" size="5" multiple><option value="">'._('(choose)').'</option>';
	$ChatterList   .= '<option value="s &#42;">'._('All guests').'</option>';
	foreach ($Chatters as $Chatter) {
		if ($Chatter[2] < $U['status']) {
			$ChatterList .= '<option value="'.$Chatter[0].'" style="'.$Chatter[1].'">'.$Chatter[0].'</option>';
		}
	}
	$ChatterList   .= '</select>';

	echo '<h2>'._('Administrative functions').'</h2>';
	echo '<i>'.$arg.'</i>';

	// Setup page button
	echo "<table>";
	if ($U['status'] >= 7) {
		thr();
		echo '<tr><td>'.form_target('view', 'setup').submit(_('Go to the Setup-Page')).'</form></td></tr>';
	}
	// Clean messages
	thr();
	echo '<tr><td><table id="clean"><tr><th>'._('Clean messages').'</th><td>';
	echo form('admin', 'clean');
	echo '<table><tr>';
	echo '<td><label><input type="radio" name="what" id="room" value="chat">'._('Chat').'</label></td>';
	if (get_setting('allow_rooms')) {
		echo '<td><label><input type="radio" name="what" id="room" value="room">'._('Whole room').'</label></td>'; 
	} else {
		echo '<td><label>&nbsp;</label></td>'; 
	}
	echo '<td><label><input type="radio" name="what" id="choose" value="choose" checked>'._('Selection').'</label></td>';
	echo '<td>&nbsp;</td>';
	echo '</tr><tr>';
	echo '<td colspan="3"><label><input type="radio" name="what" id="nick" value="nick">'._('Following nickname:').'</label> <select name="nickname" size="1"><option value="">'._('(choose)').'</option>';
	$stmt=$dbo->prepare('SELECT DISTINCT poster FROM ' . PREFIX . "messages WHERE delstatus<? AND poster!='';");
	$stmt->execute([$U['status']]);
	while ($nick=$stmt->fetch(PDO::FETCH_NUM)) {
		echo '<option value="'.htmlspecialchars($nick[0]).'">'.htmlspecialchars($nick[0]).'</option>';
	}
	echo '</select></td><td>';
	echo submit(_('Clean'), 'class="delbutton"').'</td></tr></table></form></td></tr></table></td></tr>';

	// Kick a chatter
	thr();
	echo '<tr><td><table id="kick"><tr><th>'.sprintf(_('Kick Chatter (%d minutes)'), get_setting('kickpenalty')).'</th></tr><tr><td>';
	echo form('admin', 'kick');
	echo '<table><tr><td>'._('Kickmessage:').'</td><td><input type="text" name="kickmessage" size="30"></td><td>&nbsp;</td></tr>';
	echo '<tr><td><label><input type="checkbox" name="what" value="purge" id="purge">'._('Purge messages').'</label></td><td>'.$ChatterList.'</td><td>';
	echo submit(_('Kick')).'</td></tr></table></form></td></tr></table></td></tr>';

	// Logout a chatter
	thr();
	echo '<tr><td><table id="logout"><tr><th>'._('Logout inactive Chatter').'</th><td>';
	echo form('admin', 'logout');
	echo "<table><tr><td>$ChatterList</td><td>";
	echo submit(_('Logout')).'</td></tr></table></form></td></tr></table></td></tr>';

	// View Session / Filters / Linkfilters / Tags ( or only View Session for Moderators )
	if ($U['status'] >= 7 ) {
		// Admins have access to all
		$views = ['sessions' => _('View active sessions'), 'lastseen' => _('Last time seen Members'), 'filter' => _('Filter'), 'linkfilter' => _('Linkfilter'), 'tags' => _('Tags')];
	} elseif ($U['status'] >= 6 ) {
		// S-Moderator, show also the filters & tags tools
		$views = ['sessions' => _('View active sessions'), 'filter' => _('Filter'), 'linkfilter' => _('Linkfilter'), 'tags' => _('Tags')];
	} else {
		// Moderator, show only the session stuff
		$views = ['sessions' => _('View active sessions')];
	}
	foreach ($views as $view => $title) {
		thr();
		echo "<tr><td><table id=\"$view\"><tr><th>".$title.'</th><td>';
		echo form('admin', $view);
		echo submit(_('View')).'</form></td></tr></table></td></tr>';
	}

	// Modification chat rooms.
	$roomcreateaccess = (int) get_setting('roomcreateaccess');
	if ($U['status'] >= $roomcreateaccess) {
		thr();
		echo '<tr><td><table id="chatrooms"><tr><th>'._('Chat Rooms').'</th><td>';
		echo form('admin', 'rooms');
		echo submit(_('View')).'</form></td></tr></table></td></tr>';
	}

	// Edit Topic
	thr();
	echo '<tr><td><table id="topicadmin"><tr><th>'._('Topic').'</th><td>';
	echo form('admin', 'topic');
	echo '<table><tr><td><input type="text" name="topic" size="20" value="'.get_setting('topic').'"></td><td>';
	echo submit(_('Change')).'</td></tr></table></form></td></tr></table></td></tr>';

	// Edit Topic Internal
	thr();
	echo '<tr><td><table id="topicadmin"><tr><th>'._('Internal Topic').'</th><td>';
	echo form('admin', 'internal_topic');
	echo '<table><tr><td><input type="text" name="internal_topic" size="20" value="'.get_setting('internal_topic').'"></td><td>';
	echo submit(_('Change')).'</td></tr></table></form></td></tr></table></td></tr>';

	// Edit Topic Staff -> staff_topic
	thr();
	echo '<tr><td><table id="topicadmin"><tr><th>'._('Staff Topic').'</th><td>';
	echo form('admin', 'staff_topic');
	echo '<table><tr><td><input type="text" name="staff_topic" size="20" value="'.get_setting('staff_topic').'"></td><td>';
	echo submit(_('Change')).'</td></tr></table></form></td></tr></table></td></tr>';

	// Guest access
	thr();
	echo '<tr><td><table id="guestaccess"><tr><th>'._('Change Guestaccess').'</th><td>';
	echo form('admin', 'guestaccess');
	echo '<table>';
	echo '<tr><td><select name="guestaccess">';
	echo '<option value="1"';
	if($GuestAccess === 1 ) {
		echo ' selected';
	}
	echo '>'._('Allow').'</option>';
	echo '<option value="2"';
	if ($GuestAccess === 2) {
		echo ' selected';
	}
	echo '>'._('Allow with waitingroom').'</option>';
	echo '<option value="3"';
	if ( $GuestAccess === 3 ) {
		echo ' selected';
	}
	echo '>'._('Require moderator approval').'</option>';
	echo '<option value="0"';
	if ($GuestAccess === 0 ) {
		echo ' selected';
	}
	echo '>'._('Only members').'</option>';
	if ($GuestAccess === 4 ) {
		echo '<option value="4" selected';
		echo '>'._('Disable chat').'</option>';
	}
	echo '</select></td><td>'.submit(_('Change')).'</td></tr></table></form></td></tr></table></td></tr>';

	// Moderators Options
	if ($U['status'] >= 5) {

		// Edit member status
		if ($U['status'] >= 6) {
			thr();
			echo '<tr><td><table id="status"><tr><th>'._('Members').'</th><td>';
			echo form('admin', 'status');
			echo '<table><tr><td><select name="name" size="1"><option value="">'._('(choose)').'</option>';
			$members=[];
			$result=$dbo->query('SELECT nickname, style, status FROM ' . PREFIX . 'members ORDER BY LOWER(nickname);');
			while ($temp=$result->fetch(PDO::FETCH_NUM)) {
				$members[] = [htmlspecialchars($temp[0]), $temp[1], $temp[2]];
			}
			foreach ($members as $member) {
				echo "<option value=\"$member[0]\" style=\"$member[1]\">$member[0]";
				if ($member[2] == 0) {
					echo ' (!)';
				} elseif ($member[2] == 2) {
					echo ' (SG)';
				} elseif ($member[2] == 3) {
				} elseif ($member[2] == 5) {
					echo ' (M)';
				} elseif ($member[2] == 6) {
					echo ' (SM)';
				} elseif ($member[2] == 7) {
					echo ' (A)';
				} else {
					echo ' (SA)';
				}
				echo '</option>';
			}
			echo '</select>';
			echo '<select name="set" size="1"><option value="">'._('(choose)').'</option>';
			if ($U['status'] == 8) {
				echo '<option value="-">'._('Delete from database').'</option><option value="0">'._('Deny access (!)').'</option>';
			}
			if (get_setting('suguests')) {
				echo '<option value="2">'._('Set to applicant (SG)').'</option>';
			}
			echo '<option value="3">'._('Set to regular member').'</option>';
			echo '<option value="5">'._('Set to moderator (M)').'</option>';
			if ($U['status'] > 6) {
				echo '<option value="6">'._('Set to supermod (SM)').'</option>';
			}
			if ($U['status'] == 8) {
				echo '<option value="7">'._('Set to admin (A)').'</option>';
				echo '<option value="8">'._('Set to senior admin (SA)').'</option>';
			}
			echo '</select></td><td>'.submit(_('Change')).'</td></tr></table></form></td></tr></table></td></tr>';
		}

		// Reset a member's password
		if ($U['status'] > 5) {
			thr();
			echo '<tr><td><table id="passreset"><tr><th>'._('Reset password').'</th><td>';
			echo form('admin', 'passreset');
			echo '<table><tr><td><select name="name" size="1"><option value="">'._('(choose)').'</option>';
			foreach ($members as $member) {
				echo "<option value=\"$member[0]\" style=\"$member[1]\">$member[0]</option>";
			}
			echo '</select></td><td><input type="password" name="pass" autocomplete="off"></td><td>'.submit(_('Change')).'</td></tr></table></form></td></tr></table></td></tr>';
		}

		// Register a guest to Applicant (or superguests)
		if (get_setting('suguests')) {
			thr();
			echo '<tr><td><table id="suguests"><tr><th>'._('Register Guest to Friend').'</th><td>';
			echo form('admin', 'superguest');
			echo '<table><tr><td><select name="name" size="1"><option value="">'._('(choose)').'</option>';
			foreach ($Chatters as $user) {
				if ($user[2] == 1) {
					echo "<option value=\"$user[0]\" style=\"$user[1]\">$user[0]</option>";
				}
			}
			echo '</select></td><td>'.submit(_('Register')).'</td></tr></table></form></td></tr></table></td></tr>';
		}

		// Register a guest to Member
		thr();
		echo '<tr><td><table id="register"><tr><th>'._('Register Guest or Friend to Member').'</th><td>';
		echo form('admin', 'register');
		echo '<table><tr><td><select name="name" size="1"><option value="">'._('(choose)').'</option>';
		foreach ($Chatters as $user) {
			if ($user[2] < 3) {
				echo "<option value=\"$user[0]\" style=\"$user[1]\">$user[0]</option>";
			}
		}
		echo '</select></td><td>'.submit(_('Register')).'</td></tr></table></form></td></tr></table></td></tr>';

		// Register some nick to Member even if not online
		if ($U['status'] >= 7) {
			thr();
			echo '<tr><td><table id="regnew"><tr><th>'._('Register new Member').'</th></tr><tr><td>';
			echo form('admin', 'regnew');
			echo '<table><tr><td>'._('Nickname:').'</td><td>&nbsp;</td><td><input type="text" name="name" size="20"></td><td>&nbsp;</td></tr>';
			echo '<tr><td>'._('Password:').'</td><td>&nbsp;</td><td><input type="password" name="pass" size="20" autocomplete="off"></td><td>';
			echo submit(_('Register')).'</td></tr></table></form></td></tr></table></td></tr>';
		}
	}

	// Page end
	thr();
	echo "</table><br>";
	echo form('admin').submit(_('Reload')).'</form>';
	print_end();
}

function send_alogin (): void
{
	print_start('alogin');
	echo form('setup').'<table>';
	echo '<tr><td>'._('Nickname:').'</td><td><input type="text" name="nick" size="15" autocomplete="username" autofocus></td></tr>';
	echo '<tr><td>'._('Password:').'</td><td><input type="password" name="pass" size="15" autocomplete="current-password"></td></tr>';
	send_captcha();
	echo '<tr><td colspan="2">'.submit(_('Login')).'</td></tr></table></form>';
	echo '<br><a href="?action=sa_password_reset">'._('Forgot login?').'</a><br>';
	echo language_selector();
	echo credit();
	print_end();
}

function send_choose_messages (): void
{
	global $U;

	$nncc		 = '&nc=' . substr(time(),-6);

	print_start('choose_messages');
	echo form('admin', 'clean');
	echo hidden('what', 'selected').submit(_('Delete selected messages'), 'class="delbutton"').'<br><br>';
	print_messages( $nncc, (int) $U['status']);
	echo '<br>'.submit(_('Delete selected messages'), 'class="delbutton"')."</form>";
	print_end();
}

function send_sa_password_reset (): void
{
	global $dbo;
	print_start('sa_password_reset');
	echo '<h1>'._('Reset password').'</h1>';
	if (defined('RESET_SUPERADMIN_PASSWORD') && !empty(RESET_SUPERADMIN_PASSWORD)) {
		$stmt = $dbo->query('SELECT nickname FROM ' . PREFIX . 'members WHERE status = 8 LIMIT 1;');
		if($user = $stmt->fetch(PDO::FETCH_ASSOC)){
			$mem_update = $dbo->prepare('UPDATE ' . PREFIX . 'members SET passhash = ? WHERE nickname = ? LIMIT 1;');
			$mem_update->execute([password_hash(RESET_SUPERADMIN_PASSWORD, PASSWORD_DEFAULT), $user['nickname']]);
			$sess_delete = $dbo->prepare('DELETE FROM ' . PREFIX . 'sessions WHERE nickname = ?;');
			$sess_delete->execute([$user['nickname']]);
			printf('<p>'._('Successfully reset password for username %s. Please remove the password reset define from the script again.').'</p>', $user['nickname']);
		}
	} else {
		echo '<p>'._("Please modify the script and put the following at the top of it (change the password). Then refresh this page: define('RESET_SUPERADMIN_PASSWORD', 'changeme');").'</p>';
	}
	echo '<a href="?action=setup">'._('Go to the Setup-Page').'</a>';
	echo '<br>';
	echo language_selector();
	echo credit();
	print_end();
}

function change_status (string $nick, string $status) : string 
{
	global $U, $dbo;

	$Result 	= '';
	$Operator 	= $U['status'];

	if (empty($nick)) {
		$Result = '';
	} elseif ($U['status'] == 8) {
		// bipass is the SA the owner ??
	} elseif ($U['status'] <= $status || !preg_match('/^[0235678\-]$/', $status)) {
		$Result = sprintf(_("Can't change status of %s"), htmlspecialchars($nick));
	}

	$stmt = $dbo->prepare('SELECT incognito, style FROM ' . PREFIX . 'members WHERE nickname = ? AND status < ?;');
	$stmt->execute([$nick, $U['status']]);
	if (!$old = $stmt->fetch(PDO::FETCH_NUM)) {
		$Result = sprintf(_("Can't change status of %s"), htmlspecialchars($nick));
	}
	if ($status === '-') {
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'members WHERE nickname=?;');
		$stmt->execute([$nick]);
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET status = 1, incognito = 0 WHERE nickname = ?;');
		$stmt->execute([$nick]);
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'inbox WHERE recipient = ?;');
		$stmt->execute([$nick]);
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'notes WHERE (type = 2 OR type = 3) AND editedby = ?;');
		$stmt->execute([$nick]);
		$Result = sprintf(_('%s successfully deleted from database.'), style_this(htmlspecialchars($nick), $old[1]));
	} else {
		if ($status < 5) {
			$old[0] = 0;
		}
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members SET status=?, incognito=? WHERE nickname=?;');
		$stmt->execute([$status, $old[0], $nick]);
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET status=?, incognito=? WHERE nickname=?;');
		$stmt->execute([$status, $old[0], $nick]);
		$Result = sprintf(_('Status of %s successfully changed.'), style_this(htmlspecialchars($nick), $old[1]));
	}
	return $Result;
}

function clean_selected (int $status, string $nick): void
{
	global $dbo;
	if (isset($_POST['mid'])) {
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'messages WHERE id = ? AND (poster = ? OR recipient = ? OR (poststatus < ? AND delstatus < ?));');
		foreach ($_POST['mid'] as $mid) {
			$stmt->execute([$mid, $nick, $nick, $status, $status]);
		}
	}
}

function kick_chatter (array $names, string $kickmessage, bool $purge) : bool 
{
	global $U, $dbo;

	$KickedNick	= '';

	$AllGuests  = false;
	$time   	= 60 * (get_setting('kickpenalty') - get_setting('guestexpire')) + time();

	$check  	= $dbo->prepare ('SELECT style, entry, status FROM ' . PREFIX . 'sessions WHERE nickname = ? AND status != 0 AND (status < ? OR nickname = ?);');
	$kick   	= $dbo->prepare ('UPDATE ' . PREFIX . 'sessions SET lastpost = ?, status = 0, kickmessage = ? WHERE nickname = ?;');
	// Kick all guests
	if ($names[0] === 's _') {
		// Prepare connected guests list
		$guests 	= $dbo->query ('SELECT nickname FROM ' . PREFIX . 'sessions WHERE status = 1;');
		$names  	= [];
		while ($name = $guests->fetch (PDO::FETCH_NUM)) {
			$names[]	 = $name[0];
		}
		$AllGuests 	= true;
	}
	$iCount  	= 0;
	foreach ($names as $name) {
		// Current user style, entry time, status
		$check->execute ([$name, $U['status'], $U['nickname']]);
		if ($temp	= $check->fetch (PDO::FETCH_ASSOC)) {
			// kick current user setting ban time, kickmessage
			$kick->execute ([$time, $kickmessage, $name]);
			if ($purge) {
				// deleting all current user messages
				del_all_messages ($name, (int) $temp['entry']);
			}
			if ( $temp['status'] >= 2 ) {
				// store lastlogout time is user is registered
				$updt = $dbo->prepare ('UPDATE ' . PREFIX . 'members SET lastlogout = ? WHERE nickname = ?;');
				$updt->execute ([time(), $name]);
			}
			// add current user name to kicked nick list
			$KickedNick .= style_this (htmlspecialchars($name), $temp['style']) . ', ';
			++$iCount;
		}
	}
	if ($iCount > 0) {
		if ($AllGuests) {
			add_system_message (get_setting('msgallkick'), $U['nickname']);
		} else {
			$KickedNick = substr ($KickedNick, 0, -2);
			if ($iCount > 1) {
				add_system_message (sprintf(get_setting('msgmultikick'), $KickedNick), $U['nickname']);
			} else {
				add_system_message (sprintf(get_setting('msgkick'), $KickedNick), $U['nickname']);
			}
		}
		return true;
	}
	return false;
}

function logout_chatter (array $names) : void
{
	global $U, $dbo;
	$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'sessions WHERE nickname = ? AND status < ?;');
	if ($names[0] === 's _') {
		$tmp   = $dbo->query('SELECT nickname FROM ' . PREFIX . 'sessions WHERE status = 1;');
		$names = [];
		while ($name = $tmp->fetch(PDO::FETCH_NUM)) {
			$names[] = $name[0];
		}
	}
	foreach ($names as $name) {
		$log = $dbo->prepare('UPDATE ' . PREFIX . 'members SET lastlogout = ? WHERE nickname = ?;');
		$log->execute([time(), $name]);

		$stmt->execute([$name, $U['status']]);
	}
}

// Admin function to see who's on line and for how long
function send_sessions () : void
{
	global $U, $dbo;

	$query 	= 'SELECT nickname, style, lastpost, status, useragent, ip FROM ' . PREFIX . 'sessions WHERE ';
	$query .= 'entry != 0 AND (incognito = 0 OR status < ? OR nickname = ?) ORDER BY status DESC, lastpost DESC;';
	$stmt	= $dbo->prepare($query);
	$stmt->execute([$U['status'], $U['nickname']]);
	if (!$lines = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
		$lines = [];
	}

	$trackip		= (bool) get_setting('trackip');
	$memexpire		= (int)  get_setting('memberexpire');
	$guestexpire	= (int)  get_setting('guestexpire');
	
	print_start('sessions');
	// Page title
	echo '<h1>'._('Active Sessions').'</h1>';
	echo '<table>';
	echo '<tr>';
	echo '<th>'._('Nickname').'</th>';
	echo '<th>'._('Timeout in').'</th>';
	echo '<th>'._('User-Agent').'</th>';
	if ($trackip) {
		echo '<th>'._('IP-Address').'</th>';
	}
	echo '<th>'._('Actions').'</th>';
	echo '</tr>';
	foreach ($lines as $temp) {
		if ($temp['status'] == 0) {
			$UserStatus = ' (K)';
		} elseif ($temp['status'] <= 1) {
			$UserStatus = ' (G)';
		} elseif ($temp['status'] == 2) {
			$UserStatus = ' (SG)';
		} elseif ($temp['status'] == 3) {
			$UserStatus = '';
		} elseif ($temp['status'] == 5) {
			$UserStatus = ' (M)';
		} elseif ($temp['status'] == 6) {
			$UserStatus = ' (SM)';
		} elseif ($temp['status'] == 7) {
			$UserStatus = ' (A)';
		} else {
			$UserStatus = ' (SA)';
		}

		echo '<tr>';
		echo '<td class="nickname">'.style_this(htmlspecialchars($temp['nickname']).$UserStatus, $temp['style']).'</td>';
		echo '<td class="timeout">';
		if ($temp['status'] > 2) {
			echo get_timeout((int) $temp['lastpost'], $memexpire);
		} else {
			echo get_timeout((int) $temp['lastpost'], $guestexpire);
		}
		echo '</td>';
		// Is the watcher status strictly higher then the user status ? or is the watcher the checked user ?
		if ($U['status'] > $temp['status'] || $U['nickname'] === $temp['nickname']) {
			echo '<td class="ua">'.$temp['useragent'].'</td>';
			if ($trackip) {
				echo '<td class="ip">'.$temp['ip'].'</td>';
			}
			echo '<td class="action">';
			// Action only possible on other user's not on yourself
			if ($temp['nickname'] !== $U['nickname']) {
				// Sub table in the line
				echo '<table>';
				echo '<tr>';
				if ($temp['status']!=0) {
					echo '<td>';
					echo form('admin', 'sessions');
					echo hidden('kick', '1').hidden('nick', htmlspecialchars($temp['nickname'])).submit(_('Kick')).'</form>';
					echo '</td>';
				}
				echo '<td>';
				echo form('admin', 'sessions');
				echo hidden('logout', '1').hidden('nick', htmlspecialchars($temp['nickname'])).submit($temp['status']==0 ? _('Unban') : _('Logout')).'</form>';
				echo '</td>';
				echo '</tr>';
				echo '</table>';
			} else {
				echo '-';
			}
			echo '</td>';
		} else {
			echo '<td class="ua">-</td>';
			if ($trackip) {
				echo '<td class="ip">-</td>';
			}
			echo '<td class="action">-</td>';
		}
		echo '</tr>';
	}
	echo "</table><br>";
	echo form('admin', 'sessions').submit(_('Reload')).'</form>';
	print_end();
}

?>