<?php
/*
* LE CHAT-PHP - a PHP Chat based on LE CHAT - Main program
*
* Copyright (C) 2015-2021 Daniel Winzen <daniel@danwin1210.me>
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
* status codes
* 0 - Kicked/Banned
* 1 - Guest
* 2 - Applicant
* 3 - Member
* 4 - System message
* 5 - Moderator	
* 6 - Super-Moderator
* 7 - Admin
* 8 - Super-Admin
* 9 - Private messages
*/

include_once ('modules/helpers.php');

include_once ('core/config.php');
include_once ('core/update_db.php');
include_once ('core/cron.php');

include_once ('modules/interface.php');
include_once ('modules/login.php');
include_once ('modules/members.php');
include_once ('modules/lastseen.php');
include_once ('modules/chatters.php');
include_once ('modules/profile.php');
include_once ('modules/admin.php');
include_once ('modules/setup.php');
include_once ('modules/notes.php');
include_once ('modules/help.php');
include_once ('modules/backup.php');
include_once ('modules/filters.php');
include_once ('modules/sessions.php');
include_once ('modules/smileys.php');
include_once ('modules/post.php');
include_once ('modules/controls.php');
include_once ('modules/tags.php');
include_once ('modules/gallery.php');
include_once ('modules/rooms.php');
include_once ('modules/messages.php');

define('RESET_SUPERADMIN_PASSWORD', ''); 			//comment this line and uncomment next to reset superadmin password
//define('RESET_SUPERADMIN_PASSWORD', 'changeme');	//Use this to reset your superadmin password in case you forgot it

// initialize and load variables/configuration
const LANGUAGES = [
	'ar' 		=> ['name' => 'العربية', 'locale' => 'ar', 'dir' => 'rtl'],
	'bg' 		=> ['name' => 'Български', 'locale' => 'bg_BG', 'dir' => 'ltr'],
	'cs' 		=> ['name' => 'čeština', 'locale' => 'cs_CZ', 'dir' => 'ltr'],
	'de' 		=> ['name' => 'Deutsch', 'locale' => 'de_DE', 'dir' => 'ltr'],
	'en' 		=> ['name' => 'English', 'locale' => 'en_GB', 'dir' => 'ltr'],
	'es' 		=> ['name' => 'Español', 'locale' => 'es_ES', 'dir' => 'ltr'],
	'fi' 		=> ['name' => 'Suomi', 'locale' => 'fi_FI', 'dir' => 'ltr'],
	'fr' 		=> ['name' => 'Français', 'locale' => 'fr_FR', 'dir' => 'ltr'],
	'id' 		=> ['name' => 'Bahasa Indonesia', 'locale' => 'id_ID', 'dir' => 'ltr'],
	'it' 		=> ['name' => 'Italiano', 'locale' => 'it_IT', 'dir' => 'ltr'],
	'pt' 		=> ['name' => 'Português', 'locale' => 'pt_PT', 'dir' => 'ltr'],
	'ru' 		=> ['name' => 'Русский', 'locale' => 'ru_RU', 'dir' => 'ltr'],
	'tr' 		=> ['name' => 'Türkçe', 'locale' => 'tr_TR', 'dir' => 'ltr'],
	'uk' 		=> ['name' => 'Українська', 'locale' => 'uk_UA', 'dir' => 'ltr'],
	'zh-Hans' 	=> ['name' => '简体中文', 'locale' => 'zh_CN', 'dir' => 'ltr'],
	'zh-Hant' 	=> ['name' => '正體中文', 'locale' => 'zh_TW', 'dir' => 'ltr'],
];
load_config();
$U            = [];									// This user data
$dbo; 												// = null;// Database connection
$memcached; 										// = null;// Memcached connection
$language     = LANG;								// user selected language
$locale       = LANGUAGES[LANG]['locale'];			// user selected locale
$dir          = LANGUAGES[LANG]['dir'];				// user selected language direction
$scripts      = []; 								// js enhancements
$styles       = []; 								// css styles
$chat_session      = $_REQUEST['session'] ?? ''; 		//requested session

// set session variable to cookie if cookies are enabled
if (!isset($_REQUEST['session']) && isset($_COOKIE[COOKIENAME])) {
	$chat_session = $_COOKIE[COOKIENAME];
}
$chat_session = preg_replace('/[^0-9a-zA-Z]/', '', $chat_session);

load_lang ();
check_db ();
cron ();
route ();

//  main program: decide what to do based on queries
function route () : void
{
	global $U;
	if (!isset($_REQUEST['action'])) {
		send_login();
	} elseif ($_REQUEST['action'] === 'view') {
		check_session();
		//Modification chat rooms
		if (isset($_REQUEST['room'])) {
			$switch = change_room();
			if ($switch == '') {
				check_session();
			} else {
				rooms($switch);
			}
		}
		send_messages();
	} elseif ($_REQUEST['action'] === 'redirect' && !empty($_GET['url'])) {
		send_redirect($_GET['url']);
	} elseif ($_REQUEST['action'] === 'rooms') {
        check_session();
        rooms();
	} elseif ($_REQUEST['action'] === 'wait') {
		parse_sessions();
		send_waiting_room();
	} elseif ($_REQUEST['action'] === 'post') {
		check_session();
		if (isset($_POST['kick']) && isset($_POST['sendto']) && $_POST['sendto'] !== 's _') {
			if ($U['status'] >=5 || ($U['status'] >=3 && (get_setting('memkickalways') || (get_mods_count() == 0 && get_setting('memkick'))))) {
				if (isset($_POST['what']) && $_POST['what'] === 'purge') {
					kick_chatter([$_POST['sendto']], $_POST['message'], true);
				} else {
					kick_chatter([$_POST['sendto']], $_POST['message'], false);
				}
			}
		} elseif (isset($_POST['message']) && isset($_POST['sendto'])) {
			send_post(validate_input());
		}
		send_post();
	} elseif ($_REQUEST['action'] === 'login' && isPOST()) {
		check_login();
		show_fails();
		send_frameset();
	} elseif ($_REQUEST['action'] === 'controls') {
		check_session();
		send_controls();
	} elseif ($_REQUEST['action'] === 'greeting') {
		check_session();
		send_greeting();
	} elseif ($_REQUEST['action'] === 'delete' && isPOST()) {
		check_session();
		if (!isset($_POST['what'])) {
		} elseif ($_POST['what'] === 'all') {
			if (isset($_POST['confirm'])) {
				del_all_messages('', (int) ($U['status'] == 1 ? $U['entry'] : 0));
			} else {
				send_del_confirm();
			}
		} elseif ($_POST['what'] === 'last') {
			del_last_message();
		}
		send_post();
	} elseif ($_REQUEST['action'] === 'profile' && isPOST()) {
		check_session();
		$arg = '';
		if (!isset($_POST['do'])) {
		} elseif ($_POST['do'] === 'save') {
			$arg = save_profile();
		} elseif ($_POST['do'] === 'delete') {
			if (isset($_POST['confirm'])) {
				delete_account();
			} else {
				send_delete_account();
			}
		}
		send_profile($arg);
	} elseif ($_REQUEST['action'] === 'logout' && isPOST()) {
		kill_session();
		send_logout();
	} elseif ($_REQUEST['action'] === 'colours') {
		check_session();
		send_colours();
	} elseif ($_REQUEST['action'] === 'notes' & isPOST()) {
		check_session();
		if (!isset($_POST['do'])) {
		} elseif ($_POST['do'] === 'admin'  && $U['status'] >  6) {
			send_notes(0);
		} elseif ($_POST['do'] === 'staff'  && $U['status'] >= 5) {
			send_notes(1);
		} elseif ($_POST['do'] === 'public' && $U['status'] >= 3) {
			send_notes(3);
		}
		if ($U['status'] < 3 || (!get_setting('personalnotes') && !get_setting('publicnotes'))) {
			send_access_denied();
		}
		send_notes(2);
	} elseif ($_REQUEST['action'] === 'smiley') {
		check_session();
		send_smiley();
	} elseif ($_REQUEST['action'] === 'help') {
		check_session();
		send_help();
	} elseif ($_REQUEST['action'] === 'phelp') {
		check_session();
		send_post_help();
	} elseif ($_REQUEST['action'] === 'news') {
		check_session();
		send_news();
	} elseif ($_REQUEST['action'] === 'links') {
		check_session();
		send_links();
	} elseif ($_REQUEST['action'] === 'rules') {
		check_session();
		send_rules();
	} elseif ($_REQUEST['action'] === 'viewpublicnotes') {
		check_session();
		view_publicnotes();
	} elseif ($_REQUEST['action'] === 'inbox' && isPOST()) {
		check_session();
		if(isset($_POST['do'])){
			clean_inbox_selected();
		}
		send_inbox();
	} elseif ($_REQUEST['action'] === 'download') {
		send_download();
	} elseif ($_REQUEST['action'] === 'admin' && isPOST()) {
		check_session();
		send_admin(route_admin());
	} elseif ($_REQUEST['action'] === 'gallery') {
		check_session();
  		if (!isset($_REQUEST['do'])) {
	  		send_gallery();
  		} else {
			send_gallery($_REQUEST['do']);
		}
	} elseif ($_REQUEST['action'] === 'inline' && isPOST()) {
		check_session();
		route_inline();
	} elseif ($_REQUEST['action'] === 'gal_inline' && isPOST()) {
		check_session();
		route_gallery_inline();
	} elseif ($_REQUEST['action'] === 'setup' && isPOST()) {
		route_setup();
	} elseif ($_REQUEST['action'] === 'sa_password_reset') {
		send_sa_password_reset();
	} else {
		send_login();
	}
}

function isPOST () {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

?>