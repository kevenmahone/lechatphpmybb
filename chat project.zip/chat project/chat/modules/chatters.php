<?php

function getDataURI ($imagePath) 
{
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $type = $finfo->file($imagePath);
    return 'data:' . $type . ';base64,' . base64_encode(file_get_contents($imagePath));
}

function print_chatters ( $nncc='' ) : void
{
	global $U, $dbo, $language;

	$HideEmptyClass	 = (bool) get_setting('hide_empty_classes');
	$AllowRooms		 = (bool) get_setting('allow_rooms');
	$AllowFollow	 = (bool) get_setting('allow_user_follow');
	$FollowUsrAccess = (int)  get_setting('follow_usr_access');
	$DenyPms		 = (bool) get_setting('disablepm');

	$RoomName 		 = '';
	$filter			 = '';
	$witch			 = '';

	if (isset($_REQUEST['filter'])) {
		$filter			= $_REQUEST['filter'];
	}

	if (isset($_REQUEST['follow'])) {
		$witch			= $_REQUEST['follow'];
	}

	echo '<div id="chatters"><table><tr>';

	if ($AllowRooms) {
		if ($U['roomid'] == null) {
			$RoomName	= '[Main Chat]';
			$RoomTitle	= 'messages & pm';
			if (get_setting('allow_link_in_main')) {
				$RoomTitle .= ' Allow links';
			} else {
				$RoomTitle .= ' No links';
			}
		} else {
			$CurRoom	= get_room_by_id ($U['roomid']);
			$RoomName	= $CurRoom['name'];
			if ($CurRoom['display'] == 0) {
				$RoomTitle	= 'messages & pm';
			} elseif ($CurRoom['display'] == 1) {
				$RoomTitle	= 'messages only';
			} elseif ($CurRoom['display'] == 2) {
				$RoomTitle	= 'pm only';
			}
			if ($CurRoom['withlink']) {
				$RoomTitle .= ' Allow links';
			} else {
				$RoomTitle .= ' No links';
			}
		}
	}

	if (!empty($filter)) {
		echo '<th><span class="channellink">'._('Conversation with :').' <label title="'.$filter.'"><i>'.$filter.'</i></label></span></th><td>&nbsp;</td>';
	} elseif ($AllowRooms && $U['status'] >= get_setting('roomaccess')) {
		echo '<th><span class="channellink">'._('You are in :').' <label title="'.$RoomTitle.'"><i>'.$RoomName.'</i></label></span></th>';
		if ($AllowFollow && $U['status'] >= $FollowUsrAccess) {
			echo '<td></td>';
		} else {
			echo '<td>&nbsp;</td>';
		}
	}

	echo GetMsgFilterDropDown ($witch);

	if (empty($filter)) {
		if (!$U['hidechatters']) {
			if (get_setting('allow_avatars')) {

				$av_member	=  getDataURI($_SERVER['DOCUMENT_ROOT'].'/Images/red-heart.png');
				$av_mods	=  getDataURI($_SERVER['DOCUMENT_ROOT'].'/Images/red-star.png');
				$av_smods	=  getDataURI($_SERVER['DOCUMENT_ROOT'].'/Images/bronze-star.png');
				$av_admins	=  getDataURI($_SERVER['DOCUMENT_ROOT'].'/Images/silver-star.png');
				$av_owners	=  getDataURI($_SERVER['DOCUMENT_ROOT'].'/Images/yellow-star.png');
			}
		
			if ($U['status'] >= 5) {
				$stmt = $dbo->prepare('SELECT nickname, style, status, user_caption, conv_mode, roomid FROM ' . PREFIX . 'sessions WHERE entry!=0 AND status>0 AND incognito=0 AND nickname NOT IN (SELECT ign FROM '. PREFIX . 'ignored WHERE ignby=? UNION SELECT ignby FROM '. PREFIX . 'ignored WHERE ign=?) ORDER BY status DESC, lastpost DESC;');
			} else {
				$stmt = $dbo->prepare('SELECT nickname, style, status, user_caption, conv_mode, roomid FROM ' . PREFIX . 'sessions WHERE entry!=0 AND status>0 AND incognito=0 AND nickname NOT IN (SELECT ign FROM '. PREFIX . 'ignored WHERE ignby=? UNION SELECT ignby FROM '. PREFIX . 'ignored WHERE ign=?) ORDER BY lastpost DESC;');
			}
			$stmt->execute([$U['nickname'], $U['nickname']]);
			$G = $SG = $M = $S = $A = [];

			$sess 		 = '';
			$lang 		 = '&lang='    . $language;
			$nick 		 = '&mention=';
			$send 		 = '&sendto=';
			$filt 		 = '&filter=';

			$channellink = '<a class="channellink" href="' . $_SERVER['SCRIPT_NAME'] . '?action=post' .$sess . $lang . $nncc . $send;

			if (!$DenyPms) {
				if ($U['conv_mode']) {
					$nicklink    = '<a class="nicklink" href="' . $_SERVER['SCRIPT_NAME'] . '?action=conv' .$sess . $lang . $nncc . $filt;
				} else {
					$nicklink    = '<a class="nicklink" href="' . $_SERVER['SCRIPT_NAME'] . '?action=post' .$sess . $lang . $nncc . $send;
				}	
			} else {
				$nicklink   = '<a class="nicklink" href="' . $_SERVER['SCRIPT_NAME'] . '?action=post' .$sess . $lang . $nncc . $nick;
			}

			while ($user = $stmt->fetch(PDO::FETCH_NUM)) {
				if (get_setting('allow_rooms')) {
					// MODIFICATION chat rooms
					$roomclass = 'notinroom';
					if ($U['roomid'] === $user[5]) {
						$roomclass = 'inroom';
					}
					$stmt1 = $dbo->prepare('SELECT name, type FROM ' . PREFIX . 'rooms WHERE id=? AND access<=? ;');
					$stmt1->execute([$user[5], $U['status']]);
					if ($room = $stmt1->fetch(PDO::FETCH_NUM)) {
						if ($room[1] == 0) {
							$roomname = $room[0];
						} else {
							$roomname = '** **';
						}
					} else {
						$roomname = ' ';
						if ($user[5] === null) {
							$roomname = '[Main Chat]';
						}
					}
					$roomprefix  = '<span class="'.$roomclass.'" title="'.$roomname.'">';
					$roompostfix = '</span>';
				} else {
					$roomprefix  = '';
					$roompostfix = '';
					$roomclass	 = 'inroom';
				}
				// if ((!get_setting('allow_rooms') || $roomclass == 'inroom') || ($roomclass == 'notinroom' && $roomname == '[Main Chat]')) {
					if (!$DenyPms) {
						if ($U['conv_mode']) {
							$link        = $nicklink.urlencode($user[0]).'" target="_top">'.style_this(htmlspecialchars($user[0]), $user[1]).'</a>';
						} else {
							$link        = $nicklink.urlencode($user[0]).'" target="post">'.style_this(htmlspecialchars($user[0]), $user[1]).'</a>';
						}
					} else {
						$link        = $nicklink.urlencode($user[0]).'" target="post">'.style_this(htmlspecialchars($user[0]), $user[1]).'</a>';
					}
					if ($user[2]==1) { // guest 
						$G[] = $roomprefix . $link . $roompostfix;
					} elseif ($user[2]>=7) { // admin or superadmin
						if (get_setting('allow_avatars')) {
							if ($user[2] == 7) {
								$link = $roomprefix . '<nobr><img src="' . $av_admins . '" title="'. stripslashes($user[3]) .'"alt="">' . $link . '</nobr>' . $roompostfix;
							} else {
								$link = $roomprefix . '<nobr><img src="' . $av_owners . '" title="'. stripslashes($user[3]) .'"alt="">' . $link . '</nobr>' . $roompostfix;
							}
						} else {
							$link = $roomprefix . $link . $roompostfix;
						}
						$A[] = $link;
					} elseif(($user[2] >= 5) && ($user[2] <=6)) { // moderator or supermoderator
						if (get_setting('allow_avatars')) {
							if ($user[2] == 5) {
								$link = $roomprefix . '<nobr><img src="' . $av_mods . '" title="'. stripslashes($user[3]) .'"alt="">' . $link . '</nobr>' . $roompostfix;
							} else {
								$link = $roomprefix . '<nobr><img src="' . $av_smods . '" title="'. stripslashes($user[3]) .'"alt="">' . $link . '</nobr>' . $roompostfix;
							}
						} else {
							$link = $roomprefix . $link . $roompostfix;
						}
						$S[] = $link;
					} elseif($user[2]==3) { // member
						if (get_setting('allow_avatars')) {
							$link = $roomprefix . '<nobr><img src="' . $av_member . '" title="'. stripslashes($user[3]) .'"alt="">' . $link . '</nobr>' . $roompostfix;
						} else {
							$link = $roomprefix . $link . $roompostfix;
						}
						$M[] = $link;
					} elseif($user[2]==2) { // superguest
						if (get_setting('allow_avatars')) {
							$link = $roomprefix . '<nobr><img src="' . $av_sguest . '" title="'. stripslashes($user[3]) .'"alt="">' . $link . '</nobr>' . $roompostfix;
						} else {
							$link = $roomprefix . $link . $roompostfix;
						}
						$SG[] = $link;
					}
				// }
			}
			if (!empty($A) || !$HideEmptyClass) { 
				if ($U['status'] > 5 ) { // can chat in admin channel
					echo '<th>' . $channellink . 's _" target="post">' . _('Admins') . '</a></th><td>'. (empty($A) ? '&nbsp;' : implode(' &nbsp; ', $A)) .'</td>';
				} else {
					echo '<th>'._('Admins').'</th><td>'. (empty($A) ? '&nbsp;' : implode(' &nbsp; ', $A)) .'</td>';
				}
			}	
			if (!empty($S) || !$HideEmptyClass) { 
				if ($U['status'] > 4) { // can chat in staff channel
					echo '<th>' . $channellink . 's %" target="post">' . _('Staff') . '</a></th><td>'. (empty($S) ? '&nbsp;' : implode(' &nbsp; ', $S)) .'</td>';
				} else {
					echo '<th>'._('Staff').'</th><td>'. (empty($S) ? '&nbsp;' : implode(' &nbsp; ', $S)) .'</td>';
				}
			}	
			if (!empty($M) || !$HideEmptyClass) { 
				if ($U['status'] >= 3) { // can chat in member channel
					echo '<th>' . $channellink . 's ?" target="post">' . _('Members') . '</a></th><td>'. (empty($M) ? '&nbsp;' : implode(' &nbsp; ', $M)) .'</td>';
				} else {
					echo '<th>'._('Members').'</th><td>'. (empty($M) ? '&nbsp;' : implode(' &nbsp; ', $M)) .'</td>';
				}
			}
			if (get_setting('suguests')) {
				if (!empty($SG) || !$HideEmptyClass) { 
					if($U['status'] > 1) { // can chat in member superguest
						echo '<th>' . $channellink . 's !" target="post">' . _('Friends') . '</a></th><td>'. (empty($SG) ? '&nbsp;' : implode(' &nbsp; ', $SG)) .'</td>';
					} else {
						echo '<th>'._('Friends').'</th><td>'. (empty($SG) ? '&nbsp;' : implode(' &nbsp; ', $SG)) .'</td>';
					}
				}
			}
			if (!empty($G) || !$HideEmptyClass) { 
				echo '<th>' . $channellink . 's *" target="post">' . _('') . '</a></th><td>'. (empty($G) ? '&nbsp' : implode(' &nbsp; ', $G)) .'</td>';
			}	
		}
	}
	echo '</tr></table></div>';
}

?>