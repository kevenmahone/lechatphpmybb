<?php

function send_controls () : void
{
	global $U;
	print_start('controls');
	$personalnotes        = (bool) get_setting('personalnotes');
	$publicnotes          = (bool) get_setting('publicnotes');

	$hide_reload_post_box = (bool) get_setting('hide_reload_post_box');
	$hide_reload_messages = (bool) get_setting('hide_reload_messages');
	$hide_room            = (bool) get_setting('hide_room');
	$hide_gallery         = (bool) get_setting('hide_gallery');
	$hide_profile         = (bool) get_setting('hide_profile');
	$hide_admin           = (bool) get_setting('hide_admin');
	$hide_notes           = (bool) get_setting('hide_notes');
	$hide_clone           = (bool) get_setting('hide_clone');
	$hide_rearrange       = (bool) get_setting('hide_rearrange');
	$hide_rules           = (bool) get_setting('hide_rules');
	$allow_smiley         = (bool) get_setting('allow_emojis');
	$allow_rooms		  = (bool) get_setting('allow_rooms');
	$allow_gallery		  = (bool) get_setting('allow_gallery');
	$hide_smiley          = (bool) get_setting('hide_smiley');
	$hide_help            = (bool) get_setting('hide_help');

	if (isset($_REQUEST['filter'])) {
		$filter = $_REQUEST['filter'];
	}
	
	if (!isset($_GET['sort'])) {
		$sort				  = 0;
	} else {
		$sort				  = 1;
	}

	echo '<table><tr>';

	// Show or not 'Admin' button
	if ($U['status'] >=5) {
		
		if ($allow_rooms) {
			if (empty($filter)) {
				echo '<td>' . form_target( 'view', 'view') . hidden('modroom','1') .submit('Mod Rooms', 'id="adminbutton"' ) . '</form></td>';
			}
		}
		if (!$hide_admin) {
			echo '<td>' . form_target( 'view', 'admin' ) . submit( _('Admin'), 'id="adminbutton"' ) . '</form></td>';
		}
	}

	// Small spacer
	echo '<td>&nbsp;&nbsp;</td>';

	// Show or not 'Reload Post Box' button
	if (!$hide_reload_post_box) {
		if (empty($filter)) {
			echo '<td>' . form_target( 'post', 'post' ) . submit( _('Reload Post Box') ) . '</form></td>';
		} else {
			echo '<td>' . form_target( 'post', 'post' ) . hidden('filter', $filter) . hidden('sendto', $filter) . submit( _('Reload Post Box') ) . '</form></td>';
		}
	}

	// Show or not 'Reload Messages' button
	if (!$hide_reload_messages) {
		if (empty($filter)) {
			echo '<td>' . form_target( 'view', 'view' ) . submit( _('Reload Messages') ) . '</form></td>';
		} else {
			echo '<td>' . form_target( 'view', 'view' ) . hidden('filter', $filter) . hidden('sendto', $filter) . submit( _('Reload Messages') ) . '</form></td>';
		}
	}

	// Show or not 'Profile' button
	if (!$hide_profile) {
		echo '<td>' . form_target( 'view', 'profile' ) . submit( _('Profile') ) . '</form></td>';
	}

	// Show or not 'Notes' button
	if (!$hide_notes) {
		if ($U['status'] >= 5) {
			echo '<td>' . form_target( 'view', 'notes', 'staff') . submit(_('Notes')) . '</form></td>';
		} elseif ($U['status'] >= 3 && $personalnotes == true) {
			echo '<td>' . form_target('view', 'notes') . submit(_('Notes')) . '</form></td>';
		}
		if ($U['status'] >= 3 && $publicnotes == true) {
			echo '<td>' . form_target( 'view', 'viewpublicnotes') . submit(_('View public notes')) . '</form></td>';
		}
	}

	// Show or not 'Clone' button
	if ($U['status'] >= 3) {
		if (!$hide_clone) {
			echo '<td>' . form_target( '_blank', 'login' ) . submit( _('Clone') ) . '</form></td>';
		}
	}

	// Show or not 'Rearrange' button
	if (!$hide_rearrange) {
		echo '<td>' . form_target( '_parent', 'login' ) . hidden( 'sort', $sort ) . submit( _('Rearrange') ) . '</form></td>';
	}

	// Show or not 'Rules' button
	if (!$hide_rules) {
		echo '<td>' . form_target( 'view', 'rules' ) . submit( _('Rules') ) . '</form></td>';
	}

	// Show or not 'Help' button
	if (!$hide_help) {
		echo '<td>' . form_target( 'view', 'help' ) . submit( _('Help') ) . '</form></td>';
	}

	// Small spacer
	echo '<td>&nbsp;&nbsp;</td>';

	// Show or not 'Gallery' button
	if (!$hide_gallery) {
		if ($allow_gallery) {
			if ($U['status'] >= (int)get_setting('galleryaccess')) {
				echo '<td>' . form_target( '_blank', 'gallery' ) . submit( _('Gallery'), 'id="gallerybutton"') . '</form></td>';
			}
		}
	}

	// Show or not 'Rooms' button
	if (!$hide_room) {
		if ($allow_rooms) {
			if ($U['status'] >= (int)get_setting('roomaccess')) {
				echo '<td>' . form_target( 'view', 'rooms' ) . submit( _('Rooms'), 'id="roombutton"') . '</form></td>';
			}
		}
	}

	// Show or not 'Smiley' button
	if (!$hide_smiley) {
		if ($allow_smiley) {
				echo '<td>' . form_target( '_blank', 'smiley' ) . submit( _('Emojis'), 'id="smileybutton"' ) . '</form></td>';
		}
	}

	// Small spacer
	echo '<td>&nbsp;&nbsp;</td>';

	// Show or not 'Exit Chat' button
	echo '<td>' . form_target('_parent', 'logout') . submit(_('Exit Chat'), 'id="exitbutton"') . '</form></td>';

	echo '</tr></table>';

	print_end();
}

?>