<?php

function send_help () : void
{
	global $U;
	print_start('help');
	$helptxt  = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('helptxt'));
	echo '<div id="help"><h2>'._('Help').'</h2>';
	if (!empty($helptxt)) {
		echo $helptxt;
	} else {
		echo _("All functions should be pretty much self-explaining, just use the buttons. In your profile you can adjust the refresh rate and font colour, as well as ignore users.<br><u>Note:</u> This is a chat, so if you don't keep talking, you will be automatically logged out after a while.");
		if (get_setting('imgembed')) {
			echo '<br>'._('If you want to embed an image in your post, simply put [img] in front of your image URL. Example: [img]http://example.com/images/file.jpg will embed the image in your post.');
		}
		if ($U['status'] >= 3) {
			echo '<br>'._("<b>Members</b>: You'll have some more options in your profile. You can adjust your font face, change your password anytime and of course you can delete your account.").'<br>';
		}
		if ($U['status'] >= 5) {
			echo '<br>'._("<b>Moderators</b>: Notice the Admin-button at the bottom. It'll bring up a page where you can clean the room, kick chatters, view all active sessions and disable guest access completely if needed.").'<br>';
		}
		if ($U['status'] >= 7) {
			echo '<br>'._("<b>Admins</b>: You'll be furthermore able to register guests, edit members and register new nicknames.").'<br>';
		}
	}
	echo '<br>';
	echo '</div>';
	echo '<br><hr><br><div id="backcredit">'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>'.credit().'</div>';
	print_end();
}

function send_rules () : void
{
	print_start('help');
	$rulestxt  = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('rulestxt'));
	echo '<div id="help"><h2>'._('Rules').'</h2></div>';
	echo '<div id="rules">';
	if (!empty($rulestxt)) {
		echo $rulestxt;
	} else {
		echo 'This place is where the rules come in, when someone has thought of establishing them and grasping them.';
	}
	echo '<br>';
	echo '</div>';
	echo '<br><hr><br><div id="backcredit">'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>'.credit().'</div>';
	print_end();
}

function send_news () : void
{
	$count	= 0;
	$links	= [];
	
	print_start('news');
	$news_page  = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('news_page'));
	echo '<div id="help"><h2>'._('News').'</h2></div>';
	echo '<div id="news">';
	$news_page = create_hotlinks($news_page, $count, $links);
	if (!empty($news_page)) {
		echo $news_page;
	} else {
		echo 'This place is where the News come in, when someone has thought of establishing them and grasping them.';
	}
	echo '<br>';
	echo '</div>';
	echo '<br><hr><br><div id="backcredit">'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>'.credit().'</div>';
	print_end();
}

function send_links () : void
{
	print_start('links');
	$links_page  = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('links_page'));
	echo '<div id="help"><h2>'._('Links').'</h2></div>';
	echo '<div id="links">';
	if (!empty($links_page)) {
		echo $links_page;
	} else {
		echo 'This place is where the Links will be writen, when someone has thought of establishing them and grasping them.';
	}
	echo '<br>';
	echo '</div>';
	echo '<br><hr><br><div id="backcredit">'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>'.credit().'</div>';
	print_end();
}

function send_post_help () : void
{
	print_start('help');
	$rulestxt  = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('postext'));
	echo '<div id="help"><h2>'._('Post Help').'</h2></div>';
	echo '<div id="rules">';
	if( !empty($rulestxt)) {
		echo $rulestxt;
	} else {
		echo 'This place is where the Post rules & help come in, when someone has thought of establishing them and grasping them.';
	}
	echo '<br>';
	echo '</div>';
	echo '<br><hr><br><div id="backcredit">'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>'.credit().'</div>';
	print_end();
}

?>