<?php

function get_admin_count () : int
{
	global $dbo;

	$AdminCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE status >= 7 AND status <= 8 AND incognito = 0')->fetch(PDO::FETCH_NUM);
	return (int) $AdminCount[0];
}

function get_staff_count () : int 
{
	global $dbo;

	$StaffCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE status >= 5 AND status <= 6 AND incognito = 0')->fetch(PDO::FETCH_NUM);
	return (int) $StaffCount[0];
}

function get_member_count () : int 
{
	global $dbo;

	$MemberCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE status = 3 AND incognito = 0')->fetch(PDO::FETCH_NUM);
	return (int) $MemberCount[0];
}

function get_applicant_count () : int 
{
	global $dbo;

	$ApplicantCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE status = 2 AND incognito = 0')->fetch(PDO::FETCH_NUM);
	return (int) $ApplicantCount[0];
}

function get_guest_count () : int 
{
	global $dbo;

	$guestCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE status = 1 AND incognito = 0')->fetch(PDO::FETCH_NUM);
	return (int) $guestCount[0];
}

function get_mods_count () : int 
{
	global $dbo;

	$ModsCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE status >= 5 AND status <= 8 AND incognito = 0')->fetch(PDO::FETCH_NUM);
	return (int) $ModsCount[0];
}

function get_timeout (int $lastpost, int $expire) : string
{
	$Return 	= '';

	$Seconds 	= ($lastpost + 60 * $expire) - time();
	if ($Seconds < 0) {
		$Seconds = 0;
	}
	$Minutes 	= floor($Seconds / 60);
	$Seconds   %= 60;
	if ($Minutes > 60) {
		$Hours 		= floor($Minutes / 60);
		$Minutes   %= 60;
		if ($Hours > 24) {
			$Days	= floor($Hours / 24);
			$Hours %= 24;
			$Return = sprintf('%d d %02d:%02d:%02d', $Days, $Hours, $Minutes, $Seconds);
		} else {
			$Return = sprintf('%02d:%02d:%02d', $Hours, $Minutes, $Seconds);
		}
	} else {
		$Return = sprintf('%02d:%02d', $Minutes, $Seconds);
	}
	return $Return;
}

function send_redirect (string $url) : void
{
	$url     = trim(htmlspecialchars_decode(rawurldecode($url)));
	preg_match('~^(.*)://~u', $url, $match);
	$url     = preg_replace('~^(.*)://~u', '', $url);
	$escaped = htmlspecialchars($url);
	if (isset($match[1]) && ($match[1] === 'http' || $match[1] === 'https')) {
		print_start('redirect', 0, $match[0].$escaped);
		echo '<p>'.sprintf(_('Redirecting to: %s'), "<a href=\"$match[0]$escaped\">$match[0]$escaped</a>").'</p>';
	} else {
		print_start('redirect');
		if (!isset($match[0])) {
			$match[0] = '';
		}
		if (preg_match('~^(javascript|blob|data):~', $url)) {
			echo '<p>'.sprintf(_('Dangerous non-http link requested, copy paste this link if you are really sure: %s'), "$match[0]$escaped").'</p>';
		} else {
			echo '<p>'.sprintf(_('Non-http link requested: %s'), "<a href=\"$match[0]$escaped\">$match[0]$escaped</a>").'</p>';
		}
		echo '<p>'.sprintf(_("If it's not working, try this one: %s"), "<a href=\"http://$escaped\">http://$escaped</a>").'</p>';
	}
	print_end();
}

function send_access_denied () : void
{
	global $U;
	http_response_code(403);
	print_start ('access_denied');
	echo '<h1>'._('Access denied').'</h1>';
	echo sprintf(_("You are logged in as %s and don't have access to this section."), style_this(htmlspecialchars($U['nickname']), $U['style'])).'<br>';
	echo form ('logout');
	echo submit(_('Logout'), 'id="exitbutton"')."</form>";
	print_end();
}

function send_approve_waiting () : void
{
	global $dbo;
	print_start ('approve_waiting');
	echo '<h2>'._('Waiting room').'</h2>';
	$result = $dbo->query('SELECT * FROM ' . PREFIX . 'sessions WHERE entry=0 AND status=1 ORDER BY id LIMIT 100;');
	if ($tmp = $result->fetchAll(PDO::FETCH_ASSOC)) {
		echo form('admin', 'approve');
		echo '<table>';
		echo '<tr><th>'._('Nickname').'</th><th>'._('User-Agent').'</th></tr>';
		foreach ($tmp as $temp) {
			echo '<tr>'.hidden('alls[]', htmlspecialchars($temp['nickname']));
			echo '<td><label><input type="checkbox" name="csid[]" value="'.htmlspecialchars($temp['nickname']).'">';
			echo style_this (htmlspecialchars($temp['nickname']), $temp['style']).'</label></td>';
			echo '<td>'.$temp['useragent'].'</td></tr>';
		}
		echo '</table><br><table id="action"><tr><td><label><input type="radio" name="what" value="allowchecked" id="allowchecked" checked>'._('Allow checked').'</label></td>';
		echo '<td><label><input type="radio" name="what" value="allowall" id="allowall">'._('Allow all').'</label></td>';
		echo '<td><label><input type="radio" name="what" value="denychecked" id="denychecked">'._('Deny checked').'</label></td>';
		echo '<td><label><input type="radio" name="what" value="denyall" id="denyall">'._('Deny all').'</label></td></tr><tr><td colspan="8">'._('Send message to denied:').' <input type="text" name="kickmessage" size="45"></td>';
		echo '</tr><tr><td colspan="8">'.submit(_('Submit')).'</td></tr></table></form>';
	} else {
		echo _('No more entry requests to approve.').'<br>';
	}
	echo '<br>'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>';
	print_end();
}

function send_waiting_room () : void
{
	global $U, $dbo, $language;
	$GuestAccess=(int) get_setting('guestaccess');
	if ($GuestAccess === 3 && (get_mods_count() > 0 || !get_setting('modfallback'))) {
		$wait = false;
	}else{
		$wait = true;
	}
	check_expired();
	check_kicked();
	$timeleft = get_setting('entrywait')-(time()-$U['lastpost']);
	if ($wait && ($timeleft <= 0 || $GuestAccess === 1)) {
		$U['entry'] = $U['lastpost'];
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET entry=lastpost WHERE session=?;');
		$stmt->execute([$U['session']]);
		send_frameset();
	} elseif (!$wait && $U['entry'] != 0) {
		send_frameset();
	} else {
		$refresh = (int) get_setting('defaultrefresh');
		print_start('waitingroom', $refresh, "$_SERVER[SCRIPT_NAME]?action=wait&session=$U[session]&lang=$language&nc=".substr(time(), -6));
		echo '<h2>'._('Waiting room').'</h2><p>';
		if ($wait) {
			echo sprintf(_('Welcome %1$s, your login has been delayed, you can access the chat in %2$d seconds.'), style_this(htmlspecialchars($U['nickname']), $U['style']), $timeleft);
		} else {
			echo sprintf(_('Welcome %1$s, your login has been delayed, you can access the chat as soon, as a moderator lets you in.'), style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
		echo '</p><br><p>';
		echo sprintf(_("If this page doesn't refresh every %d seconds, use the button below to reload it manually!"), $refresh);
		echo '</p><br><br>';
		echo '<hr>'.form('wait');
		echo submit(_('Reload')).'</form><br>';
		echo form('logout');
		echo submit(_('Exit Chat'), 'id="exitbutton"').'</form>';
		$rulestxt		 = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('rulestxt'));
		if (!empty($rulestxt) ){
			echo '<div id="rules"><h2>'._('Rules').'</h2><b>'.$rulestxt.'</b></div>';
		}
		print_end();
	}
}

function send_download () : void
{
	global $dbo;
	if (isset($_GET['id'])) {
		$stmt = $dbo->prepare('SELECT filename, type, data FROM ' . PREFIX . 'files WHERE hash=?;');
		$stmt->execute([$_GET['id']]);
		if ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
			send_headers();
			header("Content-Type: $data[type]");
			header("Content-Disposition: filename=\"$data[filename]\"");
			header("Content-Security-Policy: default-src 'none'");
			echo base64_decode($data['data']);
		} else {
			http_response_code(404);
			send_error(_('File not found!'));
		}
	} else {
		http_response_code(404);
		send_error(_('File not found!'));
	}
}

function print_notifications ( int $modroom=0 ) : void
{
	global $U, $dbo;

	$ShowFails	= '';
	$ShowInbox	= '';
	$ShowAccess = '';
	$ShowReload = '';

	echo '<div id="notifications">';
	echo '<table><tr>';
	$stmt	= $dbo->prepare('SELECT loginfails FROM ' . PREFIX . 'members WHERE nickname = ?;');
	$stmt->execute([$U['nickname']]);
	$temp	= $stmt->fetch(PDO::FETCH_NUM);
	if ($temp && $temp[0] > 0) {
		$ShowFails = '<td>' . form_target('_top','login') . submit(sprintf(_('%d Failed login attempt(s)'), $temp[0])) . "</form></td>";
	}

	if ($U['status'] >= 2 && $U['eninbox'] != 0) {
		$stmt	= $dbo->prepare('SELECT COUNT(*) FROM ' . PREFIX . 'inbox WHERE recipient = ?;');
		$stmt->execute([$U['nickname']]);
		$tmp	= $stmt->fetch(PDO::FETCH_NUM);
		if ($tmp[0] > 0 ) {
			$ShowInbox = '<td>' . form('inbox') . submit(sprintf(_('Read %d messages in your inbox'), $tmp[0])) . '</form></td>';
		}
	}

	if ($U['status'] >= 5) {
		if (get_setting('guestaccess') == 3) {
			$result	= $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE entry = 0 AND status = 1;');
			$temp	= $result->fetch(PDO::FETCH_NUM);
			if ($temp[0] > 0 ) {
				$ShowAccess = '<td>' . form('admin', 'approve') . submit(sprintf(_('%d new guests to approve'), $temp[0])) . '</form></td>';
			}
		}
		// Modification for mod room for rooms ( Reload Message button )
		if ($modroom == 1) {
			$ShowReload = '<td><span id="modroomreload">'. form('view') . hidden('modroom','1') . submit(_('Mod-Room Reload messages')) . '</form></span></td>';
		}
	}

	echo $ShowFails . $ShowInbox . $ShowAccess . $ShowReload;

	echo '</tr></table>';
	echo '</div>';
}

function send_greeting () : void
{
	global $U, $language;

	print_start('greeting', (int) $U['refresh'], $_SERVER['SCRIPT_NAME'].'?action=view&session='.$U['session'].'&lang='.$language);
	echo sprintf('<h1>'._('Welcome %s!').'</h1>', style_this(htmlspecialchars($U['nickname']), $U['style']));
	echo '<hr><small>';
	echo sprintf(_('If this frame does not reload in %d seconds, ' ), $U['refresh']);
	echo _('you will have to enable automatic redirection (meta refresh) in your browser. Also make sure no web filter, ');
	echo _('local proxy tool or browser plugin is preventing automatic refreshing! This could be for example "Polipo", "NoScript", etc.');
	echo _('(<br>As a workaround or in case of server/proxy reload errors) you can always use the buttons at the bottom to refresh manually.');
	echo '</small>';

	$rulestxt		 = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('rulestxt'));
	if (!empty($rulestxt)) {
		echo '<hr><div id="rules"><h2>'._('Rules')."</h2>$rulestxt</div>";
	}
	print_end();
}

?>