<?php

function show_member_status ( int $StValue) : string 
{
	$StText = '';
	if ( $StValue === 0 ) {
		$StText = _('Banned');
	} elseif ( $StValue === 2 ) {
		$StText = _('Super guest');
	} elseif ( $StValue === 3 ) {
		$StText = _('Member');
	} elseif ( $StValue === 5 ) {
		$StText = _('Moderator');
	} elseif ( $StValue === 6 ) {
		$StText = _('S Moderator');
	} elseif ( $StValue === 7 ) {
		$StText = _('Administrator');
	} elseif ( $StValue === 8 ) {
		$StText = _('S Adiministrator');
	}
	return $StText;
}

function get_members () : array
{
	global $dbo;

	$Members[] = '';
	$result    = $dbo->query('SELECT id, nickname, status, lastlogin, lastlogout, regedby, regedwhen FROM ' . PREFIX . 'members ORDER BY status DESC, nickname ASC;');
	while ($Member = $result->fetch(PDO::FETCH_ASSOC)) {
		$Members[]=['id' => $Member['id'], 'nickname' => $Member['nickname'], 'status' => $Member['status'], 'lastlogin' => $Member['lastlogin'], 'lastlogout' => $Member['lastlogout'], 'regedby' => $Member['regedby'], 'regedwhen' => $Member['regedwhen']];
	}

	return $Members;
}

function send_lastseen ( string $arg='' ) : void 
{
	global $U;
	$Members[] = '';

	$dateformat  = get_setting('dateformat');

	print_start ('lastseen');
	echo '<h2>'._('Members last login')."</h2><i>$arg</i><table>";
	thr ();
	echo '<tr><th><table><tr>';
	echo '<td>'._('Member ID:').'</td>';
	echo '<td>'._('Nickname').'</td>';
	echo '<td>'._('Reged By').'</td>';
	echo '<td>'._('Reg Date').'</td>';
	echo '<td>'._('Status').'</td>';
	echo '<td>'._('LastLogin').'</td>';
	echo '<td>'._('Duration').'</td>';
	echo '<td>'._('Last Seen').'</td>';
	echo '</tr></table></th></tr>';
	$Members = get_members ();
	$DateNow = new DateTime();
	foreach ( $Members as $Member ) {
		if (isset($Member['id'])) {

			$RegDate	= '';
			$LastIn		= '';
			$Durat		= '';
			$LSeen		= '';

			if ($Member['lastlogin'] > 0) {
				$LInTime = new DateTime();
				$LInTime->setTimestamp($Member['lastlogin']);
				$LastIn  = $LInTime->format($dateformat);
				$LastSee = $DateNow->diff($LInTime);
				$LSeen   = sprintf( _('%d day(s)'), $LastSee->format('%a'));
			}

			if ($Member['lastlogout'] > 0) {
				$LOutTime = new DateTime();
				$LOutTime->setTimestamp($Member['lastlogout']);
			}

			if ($Member['lastlogout'] > $Member['lastlogin']) {
				$Duration = $LOutTime->diff($LInTime);
				$Durat    = sprintf("%02d:%02d:%02d", $Duration->format('%h'), $Duration->format('%i'), $Duration->format('%s') );
			}

			if ($Member['regedwhen'] > 0) {
				$DateReg = new DateTime();
				$DateReg->setTimestamp($Member['regedwhen']);
				$RegDate = $DateReg->format($dateformat);
			}
			
			echo '<tr><td>';
			echo form('admin', 'lastseen').hidden('id', $Member['id']);
			echo '<table><tr><td>'._('ID :')." $Member[id]:</td>";
			echo '<td><label>'.$Member['nickname'].'</label></td>';
			echo '<td><label>'.$Member['regedby'].'</label></td>';
			echo '<td><label>'.$RegDate.'</label></td>';
			echo '<td><label>'. show_member_status($Member['status']) .'</label></td>';
			echo '<td><label>'.$LastIn.'</label></td>';
			echo '<td><label>'.$Durat.'</label></td>';
			echo '<td><label>'.$LSeen.'</label></td>';
		//	echo '<td class="filtersubmit">'.submit(_('Change')).'</td>';
			echo '</tr></table></form></td></tr>';
		}
	}
	echo '</table><br>';
	echo form ('admin', 'lastseen') .submit(_('Reload')).'</form>';
	print_end ();

	return;
}

?>