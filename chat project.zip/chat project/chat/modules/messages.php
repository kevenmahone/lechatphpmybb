<?php

function send_messages () : void
{
	global $U, $language;

	$sort		= '';
	$sess		= '';
	$roommod	= '';
	$modroom	= 0;
	$convmode	= 0;
	$filter		= '';
	$follow		= '';
	$lang		= '';

	$nncc		= '&nc='.substr(time(), -6);
	$sess		= '&session=' . $U['session'];

	if ($U['sortupdown']) {
		$sort		= '#bottom';
	}

	if ((isset($_REQUEST['modroom']) && $_REQUEST['modroom']) || (isset($_POST['modroom']) && $_POST['modroom'])) {
		$roommod	= '&modroom=1';
		$modroom	= 1;
	}

	if (isset($_REQUEST['filter'])) {
		$filter = '&filter=' . $_REQUEST['filter'];
		$convmode	= 1;
	}

	if (isset($_REQUEST['follow']) && $_REQUEST['follow'] !== 's *') {
		$follow		= '&follow=' . $_REQUEST['follow'];
	}

	$lang		= '&lang='.$language;

	print_start('messages', (int) $U['refresh'], $_SERVER['SCRIPT_NAME'].'?action=view' . $sess . $filter . $follow . $lang . $roommod . $sort  );

	echo '<a id="top"></a>';
	echo '<a id="bottom_link" href="#bottom">'._('Bottom').'</a>';

	// Modification We don't like the manual refresh box. (comment next line to avoid it)
	echo '<div id="manualrefresh"><br>' . _('Manual refresh required') . '<br>' . form('view') . submit(_('Reload')) . '</form><br></div>';


	if (!$U['sortupdown']) {
		if ($convmode == 0) {
			print_notifications( $modroom );
			print_topics ();
		}
		print_chatters( $nncc );
		print_messages( $nncc, 0, $modroom );
	} else {
		print_messages( $nncc, 0, $modroom );
		print_chatters( $nncc );
		if ($convmode == 0) {
			print_notifications( $modroom );
			print_topics ();
		}
	}

	echo '<a id="bottom"></a><a id="top_link" href="#top">'._('Top').'</a>';
	echo v_print_end();
	return;
}

function print_topics () : void 
{
	global $U;
	
	$TheTopic			= get_setting('topic');
	$TheInternalTopic	= get_setting('internal_topic');
	$StaffTopic			= get_setting('staff_topic');

	if (!empty($StaffTopic)) {
		$StaffTopic = '[Staff] -> ' . $StaffTopic;
	}

	echo '<div id="topic">' . $TheTopic . '</div>';
	if ( $U['status'] >= 3 ) {
		echo '<div id="internal_topic">' . $TheInternalTopic . '</div>';
	}
	if ( $U['status'] >= 5 ) {
		echo '<div id="staff_topic">' . $StaffTopic . '</div>';
	}
}

function print_messages ( string $nncc, int $delstatus=0, int $modroom=0) : void
{
	global $U, $dbo, $language;

	$removeEmbed = false;
	$timestamps	 = false;
	$filter 	 = '';
	$follow		 = '';

	$dateformat  = get_setting('dateformat');
	$Deny_pms	 = get_setting('disablepm');

	$lang		 = '&lang='.$language;

	if (!$U['embed'] && get_setting('imgembed')) {
		$removeEmbed = true;
	}

	if ($U['timestamps'] && !empty($dateformat)) {
		$timestamps	 = true;
	}

	if ($U['sortupdown']) {
		$direction	 = 'ASC';
	} else {
		$direction	 = 'DESC';
	}

	if ($U['status'] > 1) {
		$entry   	 = 0;
	} else {
		$entry   	 = $U['entry'];
	}

	if (isset($_REQUEST['filter'])) {
		$filter 	 = $_REQUEST['filter'];
	}

	if (isset($_REQUEST['follow'])) {
		$follow		 = $_REQUEST['follow'];
		if ($follow === 's *') {
			$follow = '';
		}
	}

	if (isset($_POST['modroom']) && $_POST['modroom'] && $U['status'] >= 5 ) {
		$modroom 	 = 1;
	}

	// Modification for visibility of channels in all roooms
	$channelvisinroom = (int) get_setting('channelvisinroom');
	if ($channelvisinroom == 0) {
		$channelvisinroom = 2;
	}

	echo '<div id="messages">';

	if ($delstatus > 0) {
		// Handle admin page 'clean' button to delete selected messages 
		$stmt = $dbo->prepare('SELECT postdate, id, text FROM ' . PREFIX . 'messages WHERE '.
		'(poststatus < ? AND delstatus < ?) OR ((poster = ? OR recipient = ?) AND postdate >= ?) ORDER BY id '.$direction.';');
		$stmt->execute([$U['status'], $delstatus, $U['nickname'], $U['nickname'], $entry]);
		while ($message=$stmt->fetch(PDO::FETCH_ASSOC)) {
			prepare_message_print($message, $removeEmbed);
			echo '<div class="msg"><label><input type="checkbox" name="mid[]" value="'.$message['id'].'">';
			if ($timestamps) {
				echo ' <small>'.date($dateformat, $message['postdate']).' - </small>';
			}
			echo ' '.$message['text'].'</label></div>';
		}
	} else {
		// Modification for modrooms in chat rooms
		$roomname = '';
		if ($U['roomid'] !== NULL) {
			$stmt1 = $dbo->prepare('SELECT name, display FROM ' . PREFIX . 'rooms WHERE id = ?');
			$stmt1->execute([$U['roomid']]);
			if ($room = $stmt1->fetch(PDO::FETCH_NUM)) {
				$roomname = $room[0];
				$roomdisp = $room[1];
			} else {
				$roomname = 'Main Chat';
				$roomdisp = 0;
			}
		} else {
			$roomname = 'Main Chat';
			$roomdisp = 0;
		}
		$roomname = '['.$roomname.']';

		// Modification for conversation mode
		if (!empty($filter)) {
			// Filter to select only one poster and his recipient for Conversation mode
			$stmt	= DoConversationModeQuery ($U['nickname'], $filter, $direction);
		} else {
			if (empty($follow)) {
				// follow is empty ... so we do normal operations
				if ($roomdisp == 0) {
					// SQL Query for [Main Chat] or no room system
					$stmt = DoMessageListQry_0 ($U['status'], $U['nickname'], $entry, $direction);
				} elseif ($roomdisp == 1) {
					// SQL Query for [xxx Room] without pm
					$stmt = DoMessageListQry_1 ($U['status'], $U['nickname'], $entry, $direction);
				} elseif ($roomdisp == 2) {
					// SQL Query for [PM Room] with PM's only
					$stmt = DoMessageListQry_2 ($U['status'], $U['nickname'], $entry, $direction);
				}
			} else {
				// We filter some one to display only he's public messages & posts
				$stmt = DoMsgFilter ( $U['status'], $follow, $entry, $U['roomid'], $direction);
			}
		}

		while ($message = $stmt->fetch(PDO::FETCH_ASSOC)) {
			// decrypt the messages ( if encrypted )
			
			prepare_message_print  ($message, $removeEmbed);
			// update the nc value to the correct one
			$message['text'] = preg_replace('/(&nc=.{6})/', $nncc, $message['text']);
			
			// Modification for chat rooms
			if ($message['poststatus'] < $channelvisinroom && 
				$message['roomid'] !== $U['roomid'] && 
				!$message['allrooms'] && !$modroom) {
				continue;
			}

			$RoomInfos = get_modroom_infos ($message, $modroom);

			if (!$RoomInfos[0]) {
				continue;
			}


			echo create_message_id ( $message );

			if ($timestamps) {
				echo create_message_timestamp ( $message, $filter );
			}

			if ($modroom) {
				echo '<spnn>'.$RoomInfos[1].'</spnn> ';
			}

			if (!$Deny_pms) {
				$send = '&sendto=' . $message['poster'];
				$nickpmlink = '<a class="pm_mark" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $send.'" target="post" ><span id="pm_mark" title="private message to '.$message['poster'].'">pm</span></a> ';
				if ($message['poststatus'] != 4 && $message['poststatus'] != 9) {
					echo $nickpmlink;
				}
			}

			if ($message['poststatus'] == 4) {
				echo '<span class="sysmsg" title="'._('system message').'">'.get_setting('sysmessagetxt')."$message[text]</span></div>";
			} else {
				$inline 		 = create_inline_menu ( $message, $filter, $modroom);
				
				$message['text'] = create_message_reference_link ( $message, $lang, $nncc );

				echo $message['text'] . $inline . '</div>';
			}
		}
	}

	echo '</div>';
}

function prepare_message_print (array &$message, bool $removeEmbed): void
{
	if (MSGENCRYPTED) {
		try {
			$message['text'] = sodium_crypto_aead_aes256gcm_decrypt ( base64_decode ( $message['text']), (string) null, AES_IV, ENCRYPTKEY );
		} catch (SodiumException $e){
			send_error ( $e->getMessage() );
		}
	}
	if ($removeEmbed) {
		$message['text'] = preg_replace_callback('/<img src="([^"]+)" rel="noreferrer" loading="lazy"><\/a>/u',
			function ( $matched ) {
				return "$matched[1]</a>";
			}
		, $message['text']);
	}
}

function del_message_by_id (string $id) 
{
	global $U, $dbo;

	if ($U['status'] >= 2 ) {
		if ( !empty($id) ) {
			$who[] = $id;
			$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'messages WHERE id=?;' );
			$stmt->execute( $who );
			$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'inbox WHERE postid=?;' );
			$stmt->execute( $who );
		}
	}

}

function del_all_messages (string $nick, int $entry): void
{
	global $dbo, $U;
	$globally = (bool) get_setting('postbox_delete_globally');
	if($globally && $U['status'] > 4){
		$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'messages;' );
		$stmt->execute();
	} else {
		if ( $nick === '' ) {
			$nick = $U[ 'nickname' ];
		}
		$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'messages WHERE poster=? AND postdate>=?;' );
		$stmt->execute( [ $nick, $entry ] );
		$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'inbox WHERE poster=? AND postdate>=?;' );
		$stmt->execute( [ $nick, $entry ] );
	}
}

function del_last_message (): void
{
	global $U, $dbo;

	if ($U['status'] > 1) {
		$entry = 0;
	} else {
		$entry = $U['entry'];
	}

	$globally = (bool) get_setting('postbox_delete_globally');

	if ($globally && $U['status'] > 4) {
		$stmt = $dbo->prepare( 'SELECT id FROM ' . PREFIX . 'messages WHERE postdate>=? ORDER BY id DESC LIMIT 1;' );
		$stmt->execute( [ $entry ] );
	} else {
		$stmt = $dbo->prepare( 'SELECT id FROM ' . PREFIX . 'messages WHERE poster=? AND postdate>=? ORDER BY id DESC LIMIT 1;' );
		$stmt->execute( [ $U[ 'nickname' ], $entry ] );
	}

	if ( $id = $stmt->fetch( PDO::FETCH_NUM ) ) {
		$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'messages WHERE id=?;' );
		$stmt->execute( $id );
		$stmt = $dbo->prepare( 'DELETE FROM ' . PREFIX . 'inbox WHERE postid=?;' );
		$stmt->execute( $id );
	}
}

// Modified
function clean_chat ()
{
	global $dbo, $U;
	$dbo->query('DELETE FROM ' . PREFIX . 'messages;');
	add_system_message (sprintf (get_setting('msgclean'), get_setting('chatname')), $U['nickname']);
}

// Modified
function clean_room ()
{
	global $dbo, $U;
	$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'messages WHERE roomid=?;');
	$stmt->execute([$U['roomid']]);
}

?>