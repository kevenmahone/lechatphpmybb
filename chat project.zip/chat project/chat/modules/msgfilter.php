<?php

function GetMsgFilterDropDown ($witch) : string 
{
	return '';
}

function DoMsgFilter ( $status, $filtered, $startime, $room, $direction)
{
	return;
}

?>