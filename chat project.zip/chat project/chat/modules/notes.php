<?php

function display_notes_selector () : string
{
	global $U;

	$HtmlText		= '';

	$personalnotes	= (bool) get_setting('personalnotes');
	$publicnotes	= (bool) get_setting('publicnotes');

	$HtmlText		= '<table><tr>';

	if ($U['status'] > 6) {
		$HtmlText		.= '<td>'.form_target('view', 'notes', 'admin').submit(_('Admin notes')).'</form></td>';
	}
	if ($U['status'] >= 5) {
		$HtmlText		.= '<td>'.form_target('view', 'notes', 'staff').submit(_('Staff notes')).'</form></td>';
	}
	if ($U['status'] >= 3 && ($personalnotes || $publicnotes)) {
		if ($personalnotes) {
			$HtmlText		.= '<td>'.form_target('view', 'notes').submit(_('Personal notes')).'</form></td>';
		}
		if ($publicnotes) {
			$HtmlText		.= '<td>'.form_target('view', 'notes', 'public').submit(_('Public notes')).'</form></td>';
		}
	}

	$HtmlText		.= '</tr></table>';

	return $HtmlText;
}

function display_notes_title (int $type) : string
{
	$HiddenDo		= '';

	if ($type === 1) {
		echo '<h2>'._('Staff notes').'</h2><p>';
		$HiddenDo	= hidden('do', 'staff');
	} elseif ($type === 0) {
		echo '<h2>'._('Admin notes').'</h2><p>';
		$HiddenDo	= hidden('do', 'admin');
	} elseif ($type === 2) {
		echo '<h2>'._('Personal notes').'</h2><p>';
		$HiddenDo	= '';
	} elseif ($type === 3) {
		echo '<h2>'._('Public notes').'</h2><p>';
		$HiddenDo	= hidden('do', 'public');
	}

	return $HiddenDo;
}

function save_current_note ( int $type, string $NoteText ) : string
{
	global $dbo, $U;

	$HtmlText		= '';
	// Encrypt current edited note if needed
	if (MSGENCRYPTED) {
		try {
			$_POST['text']	= base64_encode(sodium_crypto_aead_aes256gcm_encrypt($_POST['text'], '', AES_IV, ENCRYPTKEY));
		} catch (SodiumException $e){
			send_error($e->getMessage());
		}
	}
	// Store note to database
	$time	= time();
	$stmt	= $dbo->prepare('INSERT INTO ' . PREFIX . 'notes (type, lastedited, editedby, text) VALUES (?, ?, ?, ?);');
	$stmt->execute([$type, $time, $U['nickname'], $NoteText]);
	$HtmlText = '<b>'._('Notes saved!').'</b> ';

	return $HtmlText;
}

function get_note_count_by_type ( int $type ) : int 
{
	global $U, $dbo;

	if (($type !== 2) && ($type !== 3)) {
		$count	= $dbo->prepare('SELECT COUNT(*) FROM ' . PREFIX . 'notes WHERE type=?;');
		$count->execute([$type]);
	} else {
		$count	= $dbo->prepare('SELECT COUNT(*) FROM ' . PREFIX . 'notes WHERE type=? AND editedby=?;');
		$count->execute([$type, $U['nickname']]);
	}
	
	$num	= $count->fetch(PDO::FETCH_NUM);

	return $num[0];
}

function select_note_revision ( string $selected ) : int
{

	if (!empty($selected)) {
		$revision	= intval($selected);
	} else {
		$revision	= 0;
	}

	return $revision;
}

function read_note_from_database ( int $type, int $revision ) : array
{
	global $U, $dbo;

	$DateFormat	= get_setting('dateformat');

	if ( ($type !== 2) && ($type !== 3) ) {
		$stmt		= $dbo->prepare('SELECT * FROM ' . PREFIX . 'notes WHERE type = ? ORDER BY id DESC LIMIT 1 OFFSET '. $revision .';');
		$stmt->execute([$type]);
	} else {
		$stmt		= $dbo->prepare('SELECT * FROM ' . PREFIX . 'notes WHERE type = ? AND editedby = ? ORDER BY id DESC LIMIT 1 OFFSET '. $revision .';');
		$stmt->execute([$type, $U['nickname']]);
	}

	if ($note	= $stmt->fetch(PDO::FETCH_ASSOC)) {
		echo sprintf(_('Last edited by %1$s at %2$s'), htmlspecialchars($note['editedby']), date($DateFormat, $note['lastedited']));
	} else {
		$note['text']	= '';
	}

	return $note;
}

function send_notes (int $type) : void
{
	global $U, $dbo;

	error_reporting(E_ALL);

	$revision	= 0;


	print_start('notes');

	echo display_notes_selector ();

	$hiddendo	= display_notes_title ( $type );

	if (isset($_POST['text'])) {
		echo save_current_note ($type, $_POST['text']);
	}


	if (isset($_POST['revision'])) {
		$revision	= select_note_revision ( $_POST['revision'] );
	}

	$num		= get_note_count_by_type ( $type );

	$note		= read_note_from_database ( $type, $revision );

	if (MSGENCRYPTED) {
		try {
			$note['text']	= sodium_crypto_aead_aes256gcm_decrypt(base64_decode($note['text']), (string)null, AES_IV, ENCRYPTKEY);
		} catch (SodiumException $e){
			send_error($e->getMessage());
		}
	}

	echo "</p>" . form('notes');
	echo $hiddendo . '<textarea name="text">' . htmlspecialchars($note['text']) . '</textarea><br><br>';
	echo submit(_('Save notes')) . '</form><br>';

	if ($num > 1) {
		echo '<table><tr><td>' . _('Revisions:') . '</td>';
		if ($revision < $num - 1) {
			echo '<td>' . form('notes') . hidden('revision', $revision + 1);
			echo $hiddendo . submit(_('Older')) . '</form></td>';
		}
		if ($revision > 0) {
			echo '<td>' . form('notes') . hidden('revision', $revision - 1);
			echo $hiddendo . submit(_('Newer')) . '</form></td>';
		}
		echo '</tr></table><br>';
	}
	print_end();

}

function view_publicnotes () : void
{
	global $dbo;
	
	$dateformat = get_setting('dateformat');
	
	print_start('publicnotes');
	echo '<h2>'._('Public notes').'</h2><p>';
	$query = $dbo->query('SELECT lastedited, editedby, text FROM ' . PREFIX . 'notes INNER JOIN (SELECT MAX(id) AS latest FROM ' . PREFIX . 'notes WHERE type=3 GROUP BY editedby) AS t ON t.latest = id;');
	while($result = $query->fetch(PDO::FETCH_OBJ)){
		if (!empty($result->text)) {
			if(MSGENCRYPTED){
				try {
					$result->text = sodium_crypto_aead_aes256gcm_decrypt(base64_decode($result->text), (string)null, AES_IV, ENCRYPTKEY);
				} catch (SodiumException $e){
					send_error($e->getMessage());
				}
			}
			echo '<hr>';
			printf(_('Last edited by %1$s at %2$s'), htmlspecialchars($result->editedby), date($dateformat, $result->lastedited));
			echo '<br>';
			echo '<textarea cols="80" rows="9" readonly="true">' . htmlspecialchars($result->text) . '</textarea>';
			echo '<br>';
		}
	}
	print_end();
}

?>