<?php

function route_setup (): void
{
	global $U;
	if(!valid_admin()){
		send_alogin();
	}
	$C['sa_bool_settings']		= [
		'show_chatter_on_top'	=> _('Show chatter list over the messages'),
		'suguests' 				=> _('Enable applicants'),
		'imgembed' 				=> _('Embed images'),
		'nicktags' 				=> _('Clickable nicks in message list'),
		'trackip' 				=> _('Show session-IP'),
		'incognito' 			=> _('Incognito mode'),
		'allow_msg_mention'		=> _('Allow users to mention a message'),
		'allow_link_in_main'	=> _('Allow links in main chat room'),
		'hide_empty_classes'	=> _('Hide empty classes in chatter list'),
		'hide_sys_mess' 		=> _('Registered member can hide his system message'),
		'user_sys_mess' 		=> _('Registered member can set personnal system message'),
		'allow_js' 				=> _('Allow enhancing functionality with JavaScript'),
		'no_login_with_js'		=> _('Hide the login page commands if JavaScript is Enabled'),
		'allow_mobile'			=> _('Allow mobile devices in chat room'),
		'allow_inline_commands' => _('Allow inline commands (in message list)'),
		'allow_avatars' 		=> _('Allow avatars in chatters list'),
		'allow_conv_mode'		=> _('Allow conversation mode for PM when click in chatter list'),
		'allow_user_rename'		=> _('Allow Users to change their name'),
		'allow_gallery' 		=> _('Allow gallery'),
		'allow_rooms'			=> _('Allow multiple rooms'),
		'allow_emojis' 			=> _('Allow smiley\'s in messages'),
		'allow_tags' 			=> _('Allow tag dropdown in post'),
		'allow_posthelp'		=> _('Allow the post help in post'),
		'allow_news_button'		=> _('Allow to display a News button'),
		'allow_links_button'	=> _('Allow to display a Links button'),
		'only_one_tag' 			=> _('Only 1 dropdown box ? (disable for no)'),
	];
	$C['sa_number_settings']	= [
	];
	$C['sa_text_settings']		= [
		'emoji_path' 			=> _('Path where the smiley\'s are stored')
	];
	$C['bool_settings']			= [
		'timestamps' 			=> _('Show Timestamps'),
		'memkick' 				=> _('Members can kick, if no moderator is present'),
		'memkickalways' 		=> _('Members can always kick'),
		'forceredirect' 		=> _('Force redirection'),
		'sendmail' 				=> _('Send mail on new public message'),
		'modfallback' 			=> _('Fallback to waiting room, if no moderator is present to approve guests'),
		'disablepm' 			=> _('Disable private messages'),
		'eninbox' 				=> _('Enable offline inbox'),
		'enablegreeting' 		=> _('Show a greeting message before showing the messages'),
		'sortupdown' 			=> _('Sort messages from top to bottom'),
		'hidechatters' 			=> _('Hide list of chatters'),
		'personalnotes' 		=> _('Personal notes'),
		'publicnotes' 			=> _('Public notes'),
		'filtermodkick' 		=> _('Apply kick filter on moderators'),
		'namedoers' 			=> _('Show who kicks people or purges all messages.'),
		'hide_reload_post_box' 	=> _('Hide reload post box button'),
		'hide_reload_messages' 	=> _('Hide reload messages button'),
		'hide_profile' 			=> _('Hide profile button'),
		'hide_gallery' 			=> _('Hide gallery button'),
		'hide_room'				=> _('Hide room button'),
		'hide_admin' 			=> _('Hide admin button'),
		'hide_notes' 			=> _('Hide notes button'),
		'hide_clone' 			=> _('Hide clone button'),
		'hide_rearrange' 		=> _('Hide rearrange button'),
		'hide_help' 			=> _('Hide help button'),
		'hide_rules'			=> _('Hide rules button'),
		'hide_smiley_post' 		=> _('Hide smiley button on post box'),
		'hide_smiley' 			=> _('Hide smiley button on controls'),
		'postbox_delete_globally' => _('Apply postbox delete button globally')
	];
	$C['colour_settings']		= [
		'colbg' 				=> _('Background colour'),
		'coltxt' 				=> _('Font colour')
	];
	$C['msg_settings']			= [
		'msgenter' 				=> _('Entrance'),
		'msgexit' 				=> _('Leaving'),
		'msgmemreg' 			=> _('Member registered'),
		'msgsureg' 				=> _('Applicant registered'),
		'msgkick' 				=> _('Kicked'),
		'msgmultikick' 			=> _('Multiple kicked'),
		'msgallkick' 			=> _('All kicked'),
		'msgclean' 				=> _('Room cleaned'),
		'msgsendall' 			=> _('Message to all'),
		'msgsendsge' 			=> _('Message to super guest only'),
		'msgsendmem' 			=> _('Message to members only'),
		'msgsendmod' 			=> _('Message to staff only'),
		'msgsendadm' 			=> _('Message to admins only'),
		'msgsendprv' 			=> _('Private message'),
		'msgattache' 			=> _('Attachement'),
		'msg_java_on'			=> _('JavaScript detected on'),
		'msg_java_off'			=> _('JavaScript detected off')
	];
	$C['number_settings']		= [
		'memberexpire' 			=> _('Member timeout (minutes)'),
		'guestexpire' 			=> _('Guest timeout (minutes)'),
		'kickpenalty' 			=> _('Kick penalty (minutes)'),
		'entrywait' 			=> _('Waiting room time (seconds)'),
		'captchatime' 			=> _('Captcha timeout (seconds)'),
		'messageexpire' 		=> _('Message timeout (minutes)'),
		'messagelimit' 			=> _('Message limit (public)'),
		'maxmessage' 			=> _('Maximal message length'),
		'maxname' 				=> _('Maximal nickname length'),
		'minpass' 				=> _('Minimal password length'),
		'defaultrefresh' 		=> _('Default message reload time (seconds)'),
		'numnotes' 				=> _('Number of notes revisions to keep'),
		'maxuploadsize' 		=> _('Maximum upload size in KB'),
		'galleryaccess' 		=> _('Gallery access level'),
		'enfileupload' 			=> _('Enable file uploads'),
		'max_refresh_rate' 		=> _('Lowest refresh rate'),
		'min_refresh_rate' 		=> _('Highest refresh rate')
	];
	$C['textarea_settings']		= [
		'rulestxt' 				=> _('Rules (html)'),
		'helptxt' 				=> _('Help (html)'),
		'postext'				=> _('Post Help (html)'),
		'news_page'				=> _('News page (html)'),
		'links_page'			=> _('Links page (html)'),
		'css' 					=> _('CSS Style'),
		'disabletext' 			=> _('Chat disabled message (html)'),
	];
	$C['text_settings']			= [
		'dateformat' 			=> _('<a target="_blank" href="https://php.net/manual/en/function.date.php#refsect1-function.date-parameters" rel="noopener noreferrer">Date formating</a>'),
		'captchachars' 			=> _('Characters used in Captcha'),
		'redirect' 				=> _('Custom redirection script'),
		'chatname' 				=> _('Chat name'),
		'mailsender' 			=> _('Send mail using this address'),
		'mailreceiver' 			=> _('Send mail to this address'),
		'nickregex' 			=> _('Nickname regex'),
		'passregex' 			=> _('Password regex'),
		'externalcss' 			=> _('Link to external CSS file (on your own server)'),
		'metadescription' 		=> _('Meta description (best 50 - 160 characters for SEO)'),
		'sysmessagetxt' 		=> _('Prepend this text to system messages'),
	];
	$extra_settings				= [
		'guestaccess' 			=> _('Change Guestaccess'),
		'englobalpass' 			=> _('Enable global Password'),
		'globalpass' 			=> _('Global Password:'),
		'captcha' 				=> _('Captcha'),
		'dismemcaptcha' 		=> _('Only for guests'),
		'topic' 				=> _('Topic'),
		'internal_topic'		=> _('Internal Topic'),
		'staff_topic' 			=> _('Staff Topic'),
		'guestreg' 				=> _('Let guests register themselves'),
		'roomaccess' 			=> _('Room access level'),
		'roomcreateaccess'		=> _('Room creation level'),
		'roomexpire'			=> _('Room Timeout (minutes)'),
		'channelvisinroom'		=> _('Channels visible in all rooms'),
		'defaulttz' 			=> _('Default time zone'),
	];
	$C['settings']				= array_keys (array_merge ($extra_settings, 
									$C['sa_bool_settings'], $C['bool_settings'], 
									$C['colour_settings'], 
									$C['msg_settings'], 
									$C['sa_number_settings'], $C['number_settings'], 
									$C['textarea_settings'], 
									$C['sa_text_settings'], $C['text_settings'])); // All settings in the database
	if(!isset($_POST['do'])){
	}elseif($_POST['do']==='save'){
		save_setup($C);
	}elseif($_POST['do']==='backup' && $U['status']==8){
		send_backup($C);
	}elseif($_POST['do']==='restore' && $U['status']==8){
		restore_backup($C);
		send_backup($C);
	}elseif($_POST['do']==='destroy' && $U['status']==8){
		if(isset($_POST['confirm'])){
			destroy_chat($C);
		}else{
			send_destroy_chat();
		}
	}
	send_setup($C);
}

function save_setup (array $C): void
{
	global $dbo;
	//sanity checks and escaping
	foreach($C['msg_settings'] as $setting) {
		$key 			= array_search($setting, $C['msg_settings']);
		$_POST[$key]	= htmlspecialchars($_POST[$key]);
	}

	foreach ($C['number_settings'] as $setting) {
		settype($_POST[$setting], 'int');
	}

	foreach ($C['sa_number_settings'] as $setting) {
		settype($_POST[$setting], 'int');
	}

	foreach ($C['colour_settings'] as $setting) {
		$key			= array_search($setting, $C['colour_settings']);
		if(preg_match('/^#([a-f0-9]{6})$/i', $_POST[$key], $match)){
			$_POST[$key]			= $match[1];
		}else{
			unset($_POST[$key]);
		}
	}

	settype($_POST['guestaccess'], 'int');
	if (!preg_match('/^[01234]$/', $_POST['guestaccess'])) {
		unset($_POST['guestaccess']);
	} elseif ($_POST['guestaccess'] == 4) {
		$dbo->exec('DELETE FROM ' . PREFIX . 'sessions WHERE status<7;');
	}
	settype($_POST['englobalpass'], 'int');
	settype($_POST['captcha'], 'int');
	settype($_POST['dismemcaptcha'], 'int');
	settype($_POST['guestreg'], 'int');
	if (isset($_POST['defaulttz'])) {
		$tzs = timezone_identifiers_list();
		if (!in_array($_POST['defaulttz'], $tzs)) {
			unset($_POST['defualttz']);
		}
	}
	//$_POST['rulestxt'] = preg_replace("/(\r?\n|\r\n?)/u", '<br>', $_POST['rulestxt']);
	//$_POST['helptxt']  = preg_replace("/(\r?\n|\r\n?)/u", '<br>', $_POST['helptxt']);
	//$_POST['postext']  = preg_replace("/(\r?\n|\r\n?)/u", '<br>',$_POST['postext']);
	$_POST['chatname'] = htmlspecialchars($_POST['chatname']);
	$_POST['redirect'] = htmlspecialchars($_POST['redirect']);
	if ($_POST['memberexpire'] < 5) {
		$_POST['memberexpire'] = 5;
	}
	if ($_POST['captchatime'] < 30) {
		$_POST['memberexpire'] = 30;
	}
	$max_refresh_rate = (int) get_setting('max_refresh_rate');
	$min_refresh_rate = (int) get_setting('min_refresh_rate');
	if ($_POST['defaultrefresh'] < $min_refresh_rate) {
		$_POST['defaultrefresh'] = $min_refresh_rate;
	} elseif ($_POST['defaultrefresh'] > $max_refresh_rate) {
		$_POST['defaultrefresh'] = $max_refresh_rate;
	}
	if ($_POST['maxname'] < 1) {
		$_POST['maxname'] = 1;
	} elseif ($_POST['maxname'] > 50) {
		$_POST['maxname'] = 50;
	}
	if ($_POST['maxmessage'] < 1) {
		$_POST['maxmessage'] = 1;
	} elseif ($_POST['maxmessage'] > 16000) {
		$_POST['maxmessage'] = 16000;
	}
	if ($_POST['numnotes'] < 1) {
		$_POST['numnotes'] = 1;
	}
	if (!valid_regex($_POST['nickregex'])) {
		unset($_POST['nickregex']);
	}
	if (!valid_regex($_POST['passregex'])) {
		unset($_POST['passregex']);
	}

	// Modification chat rooms
	if (!preg_match('/^[23567]$/', $_POST['roomaccess'])) {
		unset($_POST['roomaccess']);
	}
	if (!preg_match('/^[3567]$/', $_POST['roomcreateaccess'])) {
		unset($_POST['roomcreateaccess']);
	}
	settype($_POST['roomexpire'], 'int');
	if (!preg_match('/^[2356789]$/', $_POST['channelvisinroom'])) {
		unset($_POST['channelvisinroom']);
	}
	// End modification
	
	//save values
	foreach ($C['settings'] as $setting) {
		if (isset($_POST[$setting])) {
			update_setting($setting, $_POST[$setting]);
		}
	}
}

function check_init () : bool 
{
	global $dbo;
	try {
		$dbo->query( 'SELECT null FROM ' . PREFIX . 'settings LIMIT 1;' );
	} catch (Exception $e){
		return false;
	}
	return true;
}

function send_setup (array $C): void
{
	global $U;
	print_start('setup');
	echo '<h2>'._('Chat Setup').'</h2>'.form('setup', 'save');
	echo '<table id="guestaccess">';
	thr();
	$ga=(int) get_setting('guestaccess');
	echo '<tr><td><table><tr><th>'._('Change Guestaccess').'</th><td>';
	echo '<select name="guestaccess">';
	echo '<option value="1"';
	if($ga===1){
		echo ' selected';
	}
	echo '>'._('Allow').'</option>';
	echo '<option value="2"';
	if($ga===2){
		echo ' selected';
	}
	echo '>'._('Allow with waitingroom').'</option>';
	echo '<option value="3"';
	if($ga===3){
		echo ' selected';
	}
	echo '>'._('Require moderator approval').'</option>';
	echo '<option value="0"';
	if($ga===0){
		echo ' selected';
	}
	echo '>'._('Only members').'</option>';
	echo '<option value="4"';
	if($ga===4){
		echo ' selected';
	}
	echo '>'._('Disable chat').'</option>';
	echo '</select></td></tr></table></td></tr>';
	thr();
	$englobal=(int) get_setting('englobalpass');
	echo '<tr><td><table id="globalpass"><tr><th>'._('Global Password:').'</th><td>';
	echo '<table>';
	echo '<tr><td><select name="englobalpass">';
	echo '<option value="0"';
	if($englobal===0){
		echo ' selected';
	}
	echo '>'._('Disabled').'</option>';
	echo '<option value="1"';
	if($englobal===1){
		echo ' selected';
	}
	echo '>'._('Enabled').'</option>';
	echo '<option value="2"';
	if($englobal===2){
		echo ' selected';
	}
	echo '>'._('Only for guests').'</option>';
	echo '</select></td><td>&nbsp;</td>';
	echo '<td><input type="text" name="globalpass" value="'.htmlspecialchars(get_setting('globalpass')).'"></td></tr>';
	echo '</table></td></tr></table></td></tr>';
	thr();
	$ga=(int) get_setting('guestreg');
	echo '<tr><td><table id="guestreg"><tr><th>'._('Let guests register themselves').'</th><td>';
	echo '<select name="guestreg">';
	echo '<option value="0"';
	if($ga===0){
		echo ' selected';
	}
	echo '>'._('Disabled').'</option>';
	echo '<option value="1"';
	if($ga===1){
		echo ' selected';
	}
	echo '>'._('As applicant').'</option>';
	echo '<option value="2"';
	if($ga===2){
		echo ' selected';
	}
	echo '>'._('As member').'</option>';
	echo '</select></td></tr></table></td></tr>';
	thr();
	echo '<tr><td><table id="sysmessages"><tr><th>'._('System messages').'</th><td>';
	echo '<table>';
	foreach($C['msg_settings'] as $setting => $title){
		echo "<tr><td>&nbsp;$title</td><td>&nbsp;<input type=\"text\" name=\"$setting\" value=\"".get_setting($setting).'"></td></tr>';
	}
	echo '</table></td></tr></table></td></tr>';
	foreach($C['text_settings'] as $setting => $title){
		thr();
		echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
		echo "<input type=\"text\" name=\"$setting\" value=\"".htmlspecialchars(get_setting($setting)).'">';
		echo '</td></tr></table></td></tr>';
	}
	foreach($C['colour_settings'] as $setting => $title){
		thr();
		echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
		echo "<input type=\"color\" name=\"$setting\" value=\"#".htmlspecialchars(get_setting($setting)).'">';
		echo '</td></tr></table></td></tr>';
	}
	thr();
	echo '<tr><td><table id="captcha"><tr><th>'._('Captcha').'</th><td>';
	echo '<table>';
	if(!extension_loaded('gd')){
		echo '<tr><td>'.sprintf(_('The %s extension of PHP is required for this feature. Please install it first.'), 'gd').'</td></tr>';
	}else{
		echo '<tr><td><select name="dismemcaptcha">';
		$dismemcaptcha=(bool) get_setting('dismemcaptcha');
		echo '<option value="0"';
		if(!$dismemcaptcha){
			echo ' selected';
		}
		echo '>'._('Enabled').'</option>';
		echo '<option value="1"';
		if($dismemcaptcha){
			echo ' selected';
		}
		echo '>'._('Only for guests').'</option>';
		echo '</select></td><td><select name="captcha">';
		$captcha=(int) get_setting('captcha');
		echo '<option value="0"';
		if($captcha===0){
			echo ' selected';
		}
		echo '>'._('Disabled').'</option>';
		echo '<option value="1"';
		if($captcha===1){
			echo ' selected';
		}
		echo '>'._('Simple').'</option>';
		echo '<option value="2"';
		if($captcha===2){
			echo ' selected';
		}
		echo '>'._('Moderate').'</option>';
		echo '<option value="3"';
		if($captcha===3){
			echo ' selected';
		}
		echo '>'._('Extreme').'</option>';
		echo '</select></td></tr>';
	}
	echo '</table></td></tr></table></td></tr>';
	thr();
	echo '<tr><td><table id="defaulttz"><tr><th>'._('Default time zone').'</th><td>';
	echo '<select name="defaulttz">';
	$tzs=timezone_identifiers_list();
	$defaulttz=get_setting('defaulttz');
	foreach($tzs as $tz){
		echo "<option value=\"$tz\"";
		if($defaulttz==$tz){
			echo ' selected';
		}
		echo ">$tz</option>";
	}
	echo '</select>';
	echo '</td></tr></table></td></tr>';

	foreach($C['textarea_settings'] as $setting => $title){
		thr();
		echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
		echo "<textarea name=\"$setting\" rows=\"4\" cols=\"60\">".htmlspecialchars(get_setting($setting)).'</textarea>';
		echo '</td></tr></table></td></tr>';
	}

	foreach($C['number_settings'] as $setting => $title){
		thr();
		echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
		echo "<input type=\"number\" name=\"$setting\" value=\"".htmlspecialchars(get_setting($setting)).'">';
		echo '</td></tr></table></td></tr>';
	}

	foreach($C['bool_settings'] as $setting => $title){
		thr();
		echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
		echo "<select name=\"$setting\">";
		$value=(bool) get_setting($setting);
		echo '<option value="0"';
		if(!$value){
			echo ' selected';
		}
		echo '>'._('Disabled').'</option>';
		echo '<option value="1"';
		if($value){
			echo ' selected';
		}
		echo '>'._('Enabled').'</option>';
		echo '</select></td></tr>';
		echo '</table></td></tr>';
	}

	// Multi Room
	thr();
	echo '<tr><td><table id="roomaccess"><tr><th>'._('Room access level').'</th><td>';

	echo build_level_dropdown ( 'roomaccess', (int) get_setting('roomaccess'), array (2, 3, 5, 6, 7) );
	
	echo '</td></tr>';
    echo '</table></td></tr>';

	thr();
    echo '<tr><td><table id="roomcreateaccess"><tr><th>'._('Rooms can be created by :').'.</th><td>';

	echo build_level_dropdown ( 'roomcreateaccess', (int) get_setting('roomcreateaccess'), array (3, 5, 6, 7) );

	echo '</td></tr>';
    echo '</table></td></tr>';
    thr();	

	echo '<tr><td><table id="roomexpire"><tr><th>'._('Room Timeout (minutes)').'</th><td>';
	echo '<input type="number" name="roomexpire" value="'.get_setting('roomexpire').'">';
	echo '</td></tr></table></td></tr>';
	thr();

    echo '<tr><td><table id="channelvisinroom"><tr><th>'._('Channels visible in all rooms').'</th><td>';

	echo build_level_dropdown ( 'channelvisinroom', (int) get_setting('channelvisinroom'), array (2, 3, 5, 7, 9), true );

	echo '</td></tr>';
    echo '</table></td></tr>';
	// End of Modification

	// Multi Room end
	if ($U['status']==8) {
		thr();
		echo '<tr><th>SA only settings</th></tr>';
		foreach($C['sa_bool_settings'] as $setting => $title){
			thr();
			echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
			echo "<select name=\"$setting\">";
			$value=(bool) get_setting($setting);
			echo '<option value="0"';
			if(!$value){
				echo ' selected';
			}
			echo '>'._('Disabled').'</option>';
			echo '<option value="1"';
			if($value){
				echo ' selected';
			}
			echo '>'._('Enabled').'</option>';
			echo '</select></td></tr>';
			echo '</table></td></tr>';
		}

		foreach($C['sa_number_settings'] as $setting => $title){
			thr();
			echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
			echo "<input type=\"number\" name=\"$setting\" value=\"".htmlspecialchars(get_setting($setting)).'">';
			echo '</td></tr></table></td></tr>';
		}

		foreach($C['sa_text_settings'] as $setting => $title){
			thr();
			echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
			echo "<input type=\"text\" name=\"$setting\" value=\"".htmlspecialchars(get_setting($setting)).'">';
			echo '</td></tr></table></td></tr>';
		}
	}

	thr();
	echo '<tr><td>'.submit(_('Apply')).'</td></tr></table></form><br>';

	if($U['status'] == 8) {
		echo '<table id="actions"><tr><td>';
		echo form('setup', 'backup');
		echo submit(_('Backup and restore')).'</form></td><td>';
		echo form('setup', 'destroy');
		echo submit(_('Destroy chat'), 'class="delbutton"').'</form></td></tr></table><br>';
	}
	echo form_target('_parent', 'logout');
	echo submit(_('Logout'), 'id="exitbutton"').'</form>'.credit();
	print_end();
}

function send_init (): void
{
	print_start('init');
	echo '<h2>'._('Initial Setup').'</h2>';
	echo form('init').'<table><tr><td><h3>'._('Superadmin Login').'</h3><table>';
	echo '<tr><td>'._('Superadmin Nickname:').'</td><td><input type="text" name="sunick" size="15" autocomplete="username"></td></tr>';
	echo '<tr><td>'._('Superadmin Password:').'</td><td><input type="password" name="supass" size="15" autocomplete="new-password"></td></tr>';
	echo '<tr><td>'._('Confirm Password:').'</td><td><input type="password" name="supassc" size="15" autocomplete="new-password"></td></tr>';
	echo '</table></td></tr><tr><td><br>'.submit(_('Initialise Chat')).'</td></tr></table></form>';
	echo '<p id="changelang">'._('Change language:');
	foreach(LANGUAGES as $lang=>$data){
		echo " <a href=\"$_SERVER[SCRIPT_NAME]?action=setup&amp;lang=$lang\">$data[name]</a>";
	}
	echo '</p>'.credit();
	print_end();
}

function init_chat (): void
{
	global $dbo;
	if (check_init()) {
		$suwrite=_('Database tables already exist! To continue, you have to delete these tables manually first.');
		$result=$dbo->query('SELECT null FROM ' . PREFIX . 'members WHERE status=8;');
		if ($result->fetch(PDO::FETCH_NUM)) {
			$suwrite=_('A Superadmin already exists!');
		}
	} elseif (!preg_match('/^[a-z0-9]{1,20}$/i', $_POST['sunick'])) {
		$suwrite=sprintf(_('Invalid nickname (%1$d characters maximum and has to match the regular expression "%2$s")'), 20, '^[A-Za-z1-9]*$');
	} elseif (mb_strlen($_POST['supass'])<5) {
		$suwrite=sprintf(_('Invalid password (At least %1$d characters and has to match the regular expression "%2$s")'), 5, '.*');
	} elseif ($_POST['supass']!==$_POST['supassc']) {
		$suwrite=_('Password confirmation does not match!');
	} else {
		ignore_user_abort(true);
		set_time_limit(0);
		if (DBDRIVER===0) {			//MySQL
			$memengine	= ' ENGINE=MEMORY';
			$diskengine	= ' ENGINE=InnoDB';
			$charset	= ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin';
			$primary	= 'integer PRIMARY KEY AUTO_INCREMENT';
			$longtext	= 'longtext';
		} elseif (DBDRIVER===1) {	//PostgreSQL
			$memengine	= '';
			$diskengine	= '';
			$charset	= '';
			$primary	= 'serial PRIMARY KEY';
			$longtext	= 'text';
		} else {					//SQLite
			$memengine	= '';
			$diskengine	= '';
			$charset	= '';
			$primary	= 'integer PRIMARY KEY';
			$longtext	= 'text';
		}
		$dbo->exec('CREATE TABLE ' . PREFIX . "captcha (id $primary, time integer NOT NULL, code char(5) NOT NULL)$memengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "files (id $primary, postid integer NOT NULL UNIQUE, filename varchar(255) NOT NULL, hash char(40) NOT NULL, type varchar(255) NOT NULL, data $longtext NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'files_hash ON ' . PREFIX . 'files(hash);');
		$dbo->exec('CREATE TABLE ' . PREFIX . "filter (id $primary, filtermatch varchar(255) NOT NULL, filterreplace text NOT NULL, filtercom varchar(64) DEFAULT '', allowinpm smallint NOT NULL, regex smallint NOT NULL, kick smallint NOT NULL, cs smallint NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "ignored (id $primary, ign varchar(50) NOT NULL, ignby varchar(50) NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'ign ON ' . PREFIX . 'ignored(ign);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'ignby ON ' . PREFIX . 'ignored(ignby);');
		$dbo->exec('CREATE TABLE ' . PREFIX . "members (id $primary, nickname varchar(50) NOT NULL UNIQUE, passhash varchar(255) NOT NULL, status smallint NOT NULL, refresh smallint NOT NULL, bgcolour char(6) NOT NULL, regedby varchar(50) DEFAULT '', regedwhen integer DEFAULT 0, lastlogin integer DEFAULT 0, lastlogout integer DEFAULT 0, loginfails integer unsigned NOT NULL DEFAULT 0, timestamps smallint NOT NULL, embed smallint NOT NULL, incognito smallint NOT NULL, hide_sysmess smallint NOT NULL DEFAULT 0, style varchar(255) NOT NULL, nocache smallint NOT NULL, tz varchar(255) NOT NULL, eninbox smallint NOT NULL, sortupdown smallint NOT NULL, hidechatters smallint NOT NULL, user_entry varchar(255) DEFAULT '', user_exit varchar(255) DEFAULT '', user_intro text, user_avatar text, user_caption varchar(128) DEFAULT '', conv_mode smallint NOT NULL, nocache_old smallint NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "inbox (id $primary, postdate integer NOT NULL, postid integer NOT NULL UNIQUE, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text text NOT NULL, FOREIGN KEY (recipient) REFERENCES " . PREFIX . "members(nickname) ON DELETE CASCADE ON UPDATE CASCADE)$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_poster ON ' . PREFIX . 'inbox(poster);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'inbox_recipient ON ' . PREFIX . 'inbox(recipient);');
		$dbo->exec('CREATE TABLE ' . PREFIX . "linkfilter (id $primary, filtermatch varchar(255) NOT NULL, filterreplace varchar(255) NOT NULL, filtercom varchar(64) DEFAULT '', regex smallint NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "messages (id $primary, postdate integer NOT NULL, poststatus smallint NOT NULL, poster varchar(50) NOT NULL, recipient varchar(50) NOT NULL, text text NOT NULL, delstatus smallint NOT NULL, roomid integer, allrooms smallint NOT NULL DEFAULT(0))$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'poster ON ' . PREFIX . 'messages (poster);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'recipient ON ' . PREFIX . 'messages(recipient);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'postdate ON ' . PREFIX . 'messages(postdate);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'poststatus ON ' . PREFIX . 'messages(poststatus);');
		$dbo->exec('CREATE TABLE ' . PREFIX . "notes (id $primary, type smallint NOT NULL, lastedited integer NOT NULL, editedby varchar(50) NOT NULL, text text NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'notes_type ON ' . PREFIX . 'notes(type);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'notes_editedby ON ' . PREFIX . 'notes(editedby);');
		$dbo->exec('CREATE TABLE ' . PREFIX . "sessions (id $primary, session char(32) NOT NULL UNIQUE, nickname varchar(50) NOT NULL UNIQUE, status smallint NOT NULL, refresh smallint NOT NULL, style varchar(255) NOT NULL, lastpost integer NOT NULL, passhash varchar(255) NOT NULL, postid char(6) NOT NULL DEFAULT '000000', useragent varchar(255) NOT NULL, kickmessage varchar(255) DEFAULT '', bgcolour char(6) NOT NULL, entry integer NOT NULL, timestamps smallint NOT NULL, embed smallint NOT NULL, incognito smallint NOT NULL, hide_sysmess smallint NOT NULL DEFAULT 0, ip varchar(45) NOT NULL, nocache smallint NOT NULL, tz varchar(255) NOT NULL, eninbox smallint NOT NULL, sortupdown smallint NOT NULL, hidechatters smallint NOT NULL, user_entry varchar(255) DEFAULT '', user_exit varchar(255) DEFAULT '', user_caption varchar(128) DEFAULT '', conv_mode smallint NOT NULL, roomid integer, nocache_old smallint NOT NULL)$memengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'status ON ' . PREFIX . 'sessions(status);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'lastpost ON ' . PREFIX . 'sessions(lastpost);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'incognito ON ' . PREFIX . 'sessions(incognito);');
		$dbo->exec('CREATE TABLE ' . PREFIX . "settings (setting varchar(50) NOT NULL PRIMARY KEY, value text NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "tags (id $primary, tag_dropdown varchar(10) NOT NULL , tag_id smallint(4) NOT NULL , tag_text varchar(30) NOT NULL , tag_ehtext varchar(200) NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE TABLE ' . PREFIX . "emojis (id $primary, emoji varchar(20) NOT NULL , file varchar(255) NOT NULL , inpage boolean NOT NULL , user_level smallint(2) NOT NULL, height smallint(3) NOT NULL , width smallint(3) NOT NULL)$diskengine$charset;");
		// Modification for chat rooms
		$dbo->exec('CREATE TABLE ' . PREFIX . "rooms (id $primary, creator varchar(60) DEFAULT '', name varchar(50) NOT NULL UNIQUE, access smallint NOT NULL, time integer NOT NULL, permanent smallint NOT NULL DEFAULT(0) , display smallint(2) NOT NULL, type smallint(2) NOT NULL, password varchar(32) DEFAULT '', withlink smallint(2) NOT NULL)$diskengine$charset;");
		$dbo->exec('CREATE INDEX ' . PREFIX . 'sroomid ON ' . PREFIX . 'sessions(roomid);');
		$dbo->exec('CREATE INDEX ' . PREFIX . 'mroomid ON ' . PREFIX . 'messages(roomid);');

		$settings = [
			['show_chatter_on_top', '1'],
			['guestaccess', '0'],
			['globalpass', ''],
			['englobalpass', '0'],
			['nicktags', '0'],
			['captcha', '0'],
			['dateformat', 'm-d H:i:s'],
			['helptxt', ''],
			['rulestxt', ''],
			['news_page', ''],
			['links_page', ''],
			['msgencrypted', '0'],
			['dbversion', DBVERSION],
			['css', ''],
			['memberexpire', '60'],
			['guestexpire', '15'],
			['kickpenalty', '10'],
			['entrywait', '120'],
			['messageexpire', '14400'],
			['messagelimit', '150'],
			['maxmessage', 2000],
			['captchatime', '600'],
			['colbg', '000000'],
			['coltxt', 'FFFFFF'],
			['maxname', '20'],
			['minpass', '5'],
			['defaultrefresh', '20'],
			['dismemcaptcha', '0'],
			['suguests', '0'],
			['imgembed', '1'],
			['timestamps', '1'],
			['trackip', '0'],
			['captchachars', '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'],
			['memkick', '1'],
			['memkickalways', '0'],
			['namedoers', '1'],
			['forceredirect', '0'],
			['redirect', ''],
			['incognito', '1'],
			['chatname', 'My Chat'],
			['topic', ''],
			['internal_topic', ''],
			['staff_topic', ''],
			['msgsendall', _('%s - ')],
			['msgsendsge', _('[RG] %s - ')],
			['msgsendmem', _('[M] %s - ')],
			['msgsendmod', _('[Staff] %s - ')],
			['msgsendadm', _('[Admin] %s - ')],
			['msgsendprv', _('[%1$s to %2$s] - ')],
			['msgenter', _('%s entered the chat.')],
			['msgexit', _('%s left the chat.')],
			['msgmemreg', _('%s is now a registered member.')],
			['msgsureg', _('%s is now a registered applicant.')],
			['msgkick', _('%s has been kicked.')],
			['msgmultikick', _('%s have been kicked.')],
			['msgallkick', _('All guests have been kicked.')],
			['msgclean', _('%s has been cleaned.')],
			['msg_java_on',	 _('!! JAVASCRIPT IS ENABLED !!')],
			['msg_java_off', _('- JAVASCRIPT IS DISABLED -')],
			['no_login_with_js', '1'],
			['numnotes', '3'],
			['mailsender', 'www-data <www-data@localhost>'],
			['mailreceiver', 'Webmaster <webmaster@localhost>'],
			['sendmail', '0'],
			['modfallback', '1'],
			['guestreg', '0'],
			['disablepm', '0'],
			['disabletext', '<h1>'._('Temporarily disabled').'</h1>'],
			['defaulttz', 'UTC'],
			['eninbox', '0'],
			['passregex', '.*'],
			['nickregex', '^[A-Za-z0-9]*$'],
			['externalcss', ''],
			['enablegreeting', '0'],
			['sortupdown', '0'],
			['hidechatters', '0'],
			['hide_empty_classes', '0'],
			['enfileupload', '0'],
			['msgattache', '%2$s [%1$s]'],
			['maxuploadsize', '1024'],
			['galleryaccess', '3'],
			['nextcron', '0'],
			['personalnotes', '1'],
			['publicnotes', '1'],
			['filtermodkick', '0'],
			['metadescription', _('A chat community')],
			['sysmessagetxt', 'ℹ️ &nbsp;'],
			['hide_sys_mess', '0'],
			['user_sys_mess', '0'],
			['hide_reload_post_box', '0'],
			['hide_reload_messages', '0'],
			['hide_profile', '0'],
			['hide_gallery', '0'],
			['hide_admin', '0'],
			['hide_notes', '0'],
			['hide_clone', '0'],
			['hide_rearrange', '0'],
			['hide_help', '0'],
			['hide_rules', '0'],
			['hide_smiley', '0'],
			['hide_smiley_post', '0'],
			['max_refresh_rate', '150'],
			['min_refresh_rate', '5'],
			['postbox_delete_globally', '0'],
			['allow_conv_mode', '0'],
			['allow_inline_commands', '0'],
			['allow_gallery', '0'],
			['allow_rooms', '0'],
			['emoji_path',  ''],
			['allow_emojis', '0'],
			['allow_tags', '0'],
			['allow_avatars', '0'],
			['allow_link_in_main', '1'],
			['allow_news_button', '0'],
			['allow_links_button', '0'],
			['allow_msg_mention', '0'],
			['allow_user_follow', '0'],
			['allow_user_rename', '0'],
			['follow_usr_access', '3'],
			['only_one_tag', '0'],
			['roomcreateaccess', '7'],	
            ['roomexpire', '10'],
            ['channelvisinroom', '2'],
			['allow_js', '1'],
			['allow_mobile', '0']
		];

		$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'settings (setting, value) VALUES (?, ?);');
		foreach ($settings as $pair) {
			$stmt->execute($pair);
		}

		$reg = [
			'nickname'		=> $_POST['sunick'],
			'passhash'		=> password_hash($_POST['supass'], PASSWORD_DEFAULT),
			'regedby'		=> 'Owner',
			'regedwhen'		=> time(),
			'status'		=> 8,
			'refresh'		=> 20,
			'bgcolour'		=> '000000',
			'timestamps'	=> 1,
			'style'			=> 'color:#FFFFFF;',
			'embed'			=> 1,
			'conv_mode'		=> 0,
			'incognito'		=> 0,
			'nocache'		=> 0,
			'nocache_old'	=> 1,
			'tz'			=> 'UTC',
			'eninbox'		=> 0,
			'sortupdown'	=> 0,
			'hidechatters'	=> 0,
		];

		$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'members (nickname, passhash, regedby, status, refresh, bgcolour, regedwhen, timestamps, style, embed, incognito, conv_mode, nocache, tz, eninbox, sortupdown, hidechatters, nocache_old) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
		$stmt->execute([$reg['nickname'], $reg['passhash'], $reg['regedby'], $reg['status'], $reg['refresh'], $reg['bgcolour'], $reg['regedwhen'],$reg['timestamps'], $reg['style'], $reg['embed'], $reg['incognito'], $reg['conv_mode'], $reg['nocache'], $reg['tz'], $reg['eninbox'], $reg['sortupdown'], $reg['hidechatters'], $reg['nocache_old']]);
		$suwrite = _('Successfully registered!');
	}

	print_start ('init');
	echo '<h2>'._('Initial Setup').'</h2><br><h3>'._('Superadmin Login').'</h3>'.$suwrite.'<br><br><br>';
	echo form ('setup');
	echo submit(_('Go to the Setup-Page')).'</form>';
	echo credit();
	print_end ();
}

function send_destroy_chat (): void
{
	print_start('destroy_chat');
	echo '<table><tr><td colspan="2">'._('Are you sure?').'</td></tr><tr><td>';
	echo form_target('_parent', 'setup', 'destroy').hidden('confirm', 'yes').submit(_('Yes'), 'class="delbutton"').'</form></td><td>';
	echo form('setup').submit(_('No'), 'class="backbutton"').'</form></td><tr></table>';
	print_end();
}

function destroy_chat (array $C): void
{
	global $dbo, $memcached, $chat_session;
	setcookie(COOKIENAME, false);
	$chat_session = '';
	print_start('destroy');
	$dbo->exec('DROP TABLE ' . PREFIX . 'captcha;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'files;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'filter;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'ignored;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'inbox;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'linkfilter;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'tags;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'rooms;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'emojis;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'members;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'messages;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'notes;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'sessions;');
	$dbo->exec('DROP TABLE ' . PREFIX . 'settings;');
	if(MEMCACHED){
		$memcached->delete(DBNAME . '-' . PREFIX . 'filter');
		$memcached->delete(DBNAME . '-' . PREFIX . 'linkfilter');
		$memcached->delete(DBNAME . '-' . PREFIX . 'tags;');
		$memcached->delete(DBNAME . '-' . PREFIX . 'emojis;');
			foreach($C['settings'] as $setting){
			$memcached->delete(DBNAME . '-' . PREFIX . "settings-$setting");
		}
		$memcached->delete(DBNAME . '-' . PREFIX . 'settings-dbversion');
		$memcached->delete(DBNAME . '-' . PREFIX . 'settings-msgencrypted');
		$memcached->delete(DBNAME . '-' . PREFIX . 'settings-nextcron');
	}
	echo '<h2>'._('Successfully destroyed chat').'</h2><br><br><br>';
	echo form('setup').submit(_('Initial Setup')).'</form>'.credit();
	print_end();
}

function get_setting (string $setting) : string 
{
	global $dbo, $memcached;
	$value = '';
	if($dbo instanceof PDO && ( !MEMCACHED || ! ($value = $memcached->get(DBNAME . '-' . PREFIX . "settings-$setting") ) ) ){
		try {
			$stmt = $dbo->prepare( 'SELECT value FROM ' . PREFIX . 'settings WHERE setting=?;' );
			$stmt->execute( [ $setting ] );
			$stmt->bindColumn( 1, $value );
			$stmt->fetch( PDO::FETCH_BOUND );
			if ( MEMCACHED ) {
				$memcached->set( DBNAME . '-' . PREFIX . "settings-$setting", $value );
			}
		} catch (Exception $e){
			return '';
		}
	}
	return $value;
}

function update_setting (string $setting, $value): void
{
	global $dbo, $memcached;
	$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'settings SET value=? WHERE setting=?;');
	$stmt->execute([$value, $setting]);
	if(MEMCACHED){
		$memcached->set(DBNAME . '-' . PREFIX . "settings-$setting", $value);
	}
}

function valid_admin () : bool 
{
	global $U;

	parse_sessions();
	if (!isset($U['session']) && isset($_POST['nick']) && isset($_POST['pass'])) {
		create_session(true, $_POST['nick'], $_POST['pass']);
	}
	if (isset($U['status'])) {
		if ($U['status'] >= 7) {
			return true;
		}
		send_access_denied();
	}
	return false;
}

function build_level_dropdown ( string $name, int $value, array $options, bool $channel = false ) : string {
	$display	 = '';

	$display	 = '<select name="'.$name.'">';
    foreach ($options as $option) {
		$display	.= '<option value="'.$option.'"';
		
		if ($value == $option) {
			$display	.= ' selected';
		}
		
		if ($option == 2) {
			$display	.= '>'. ( ($channel) ? _('All Channels')   : _('Friends')    ) .'</option>';
		} elseif ($option == 3) {
			$display	.= '>'. ( ($channel) ? _('Member Channel') : _('Members')    ) .'</option>';
		} elseif ($option == 5) {
			$display	.= '>'. ( ($channel) ? _('Staff Channel')  : _('Moderators') ) .'</option>';
		} elseif ($option == 6) {
			$display	.= '>'. ( ($channel) ? _('') : _('Super Moderators')         ) .'</option>';
		} elseif ($option == 7) {
			$display	.= '>'. ( ($channel) ? _('Admin Channel')  : _('Admins')     ) .'</option>';
		} elseif ($option == 9) {
			$display	.= '>'. ( ($channel) ? _('No Channel')     : _('')           ) .'</option>';
		}
	}
	$display	.= '</select>'; 

	return $display;
}

?>