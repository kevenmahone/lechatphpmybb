<?php

class ScanFolder 
{
    private $add_systemfiles = false;
    private $systemfiles     = array(".", "..", ".htaccess", ".htpasswd");
    private $extensions      = array("gif", "png");
    private $add_extra       = false;
 
    public function listfiles($folder) {
        $out=array();
        if(is_dir($folder) === false) {
            throw new Exception("Invalid path ".$folder);
        }
        $files = scandir($folder);
        foreach($files as $file) {
            if ($this->isValidFile($file)) {                
                if ($this->add_extra==true) {
                    $f = pathinfo($file);
                    $out[]=$f;
                } else {
                    $out[]=$file;
                }
            }
        }
        return $out;
    }

    public function displaySystemFiles($add) {
        $this->add_systemfiles=$add;
    }
 
    public function setExtensionFilter(array $exts) {
        $this->extensions=$exts;
    }

    public function setExtra($add) {
        $this->add_extra=$add;
    }
 
    private function isValidFile($file) {
        if ($this->add_systemfiles==false && in_array($file, $this->systemfiles)) {
            return false;
        }
 
        if (count($this->extensions)>0) {
            $ext=strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (!in_array($ext, $this->extensions)) {
                return false;
            }
        }
 
        return true;
    }
    private function fileType($file, $path) {
        if (in_array($file, $this->systemfiles)) {
            return 'system';
        } else if (is_file($path.'/'.$file) && is_readable($path.'/'.$file)) {
            return 'file';
        } else if (is_dir($path.'/'.$file) && is_readable($path.'/'.$file)) {
            return 'dir';
        } else {
            return 'undefined';
        }
    }
}

function send_smiley () 
{
    global $dbo, $U;

    $scanFolder = new ScanFolder();
    $scanFolder->displaySystemFiles(false);
    $scanFolder->setExtra(true);
    $smileyPath = get_setting('emoji_path');
    $files      = $scanFolder->listfiles($_SERVER['DOCUMENT_ROOT']. $smileyPath );

	print_start('emojis');

    echo '<br><h1>'.get_setting('chatname').' '._('Emoji\'s').'</h1><br>';
    echo '<h3>'._('Emoji\'s can be used by using the following keywords (triple click to select)').'</h3>';
    echo '<table><tbody>';

    $col        = 0;
    $NbrCols    = 5;
    $emojis     = count($files);

    foreach ($files as $file) {
        if ($file['extension']=== "gif" || $file['extension']=== "png") {
            if ($col == 0) {
                echo '<tr>';
            }
            echo '<td>:'.$file['filename'].':<br><img src="/Smiley_files/'.$file['basename'].'" height="35px" title=":'.$file['filename'].':" alt="'.$file['filename'].'"></td>';
            $col += 1;
            if ($col >= $NbrCols){
                echo '</tr>';
                $col = 0;
            }
        }
    }

    // Finish the table with empty cells
    if ($col > 0) {
        while ($col<$NbrCols) {
            echo '<td></td>';
            $col += 1;
        }
        echo '</tr>';    
    }

    echo '</tbody></table>';

	print_end();
}


?>