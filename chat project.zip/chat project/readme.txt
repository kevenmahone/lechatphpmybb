upload into /var/www/html/mybb/chat/   the file from chat folder chmod 777 to everything
upload the plugin inside mybb plugin place


edit in chat folder the config file to add your database - username - password ... Can be the same as the forum.